// src/services/api.jsx
const API_BASE_URL = 'http://localhost:8080/api';

const fetchApi = async (endpoint, options = {}) => {
  const token = localStorage.getItem('token');
  const headers = {};

  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const contentType = res.headers.get('content-type') || '';

  // Leer cuerpo (JSON o texto)
  const rawBody = contentType.includes('application/json') ? await res.json() : await res.text();

  if (!res.ok) {
    // Si el backend devuelve un ApiResponse.error, puede estar en rawBody.message o en rawBody
    const errMsg = rawBody && rawBody.message ? rawBody.message : (typeof rawBody === 'string' ? rawBody : JSON.stringify(rawBody));
    throw new Error(errMsg || `Error ${res.status}`);
  }

  // Backend envuelve las respuestas en ApiResponse<T> { success, message, data, timestamp }
  if (rawBody && typeof rawBody === 'object' && ('success' in rawBody)) {
    return rawBody.data;
  }

  return rawBody;
};

export default fetchApi;