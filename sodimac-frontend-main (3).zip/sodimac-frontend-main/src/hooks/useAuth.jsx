import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';
import fetchApi from '@/services/api';

const AuthContext = createContext(null);
const USER_KEY = 'user';
const TOKEN_KEY = 'token';

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);      // { id, name, email, role }
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem(USER_KEY);
      const storedToken = localStorage.getItem(TOKEN_KEY);
      if (storedUser && storedToken) {
        setUser(JSON.parse(storedUser));
        setToken(storedToken);
      }
    } catch (err) {
      console.error('Error reading auth from localStorage', err);
      localStorage.removeItem(USER_KEY);
      localStorage.removeItem(TOKEN_KEY);
    } finally {
      setLoading(false);
    }
  }, []);

  // Sync logout across tabs
  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === TOKEN_KEY && e.newValue === null) {
        setUser(null);
        setToken(null);
        toast({ title: 'Sesión cerrada', description: 'Tu sesión ha sido cerrada en otra pestaña.' });
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  // Helpers
  const persistAuth = (tokenValue, userObj) => {
    if (tokenValue) {
      localStorage.setItem(TOKEN_KEY, tokenValue);
      setToken(tokenValue);
    }
    if (userObj) {
      localStorage.setItem(USER_KEY, JSON.stringify(userObj));
      setUser(userObj);
    }
  };

  const clearAuth = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    setToken(null);
    setUser(null);
  };

  // Login: POST /auth/login -> AuthResponseDTO { token, tipo, idUsuario, email, rol, nombreCompleto }
  const login = async (email, password) => {
    const data = await fetchApi('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    // data = AuthResponseDTO
    if (!data || !data.token) throw new Error('No se recibió token del servidor');
    const userObj = {
      id: data.idUsuario,
      name: data.nombreCompleto || data.email,
      email: data.email,
      role: data.rol ? data.rol.toLowerCase() : null,
    };
    persistAuth(data.token, userObj);
    toast({ title: 'Inicio de sesión', description: `Bienvenido ${userObj.name}` });
    return userObj;
  };

  // Register: POST /auth/register expects RegisterRequestDTO
  const register = async (registerData) => {
    // mapear campos del formulario a DTO backend
    const payload = {
      email: registerData.email,
      password: registerData.password,
      nombreCompleto: registerData.name || registerData.nombreCompleto || '',
      telefono: registerData.phone || registerData.telefono || '',
      direccion: registerData.address || registerData.direccion || '',
      rol: registerData.role || 'candidate'
    };
    // backend puede devolver AuthResponseDTO (si auto-login), o solo message
    const data = await fetchApi('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    // si vino token, persistir y devolver user
    if (data && data.token) {
      const userObj = {
        id: data.idUsuario,
        name: data.nombreCompleto || data.email,
        email: data.email,
        role: data.rol ? data.rol.toLowerCase() : null,
      };
      persistAuth(data.token, userObj);
      toast({ title: 'Registro', description: 'Registro completado. Sesión iniciada.' });
      return userObj;
    }
    toast({ title: 'Registro', description: 'Registro completado. Por favor inicia sesión.' });
    return null;
  };

  const logout = useCallback(() => {
    clearAuth();
    // desencadenar storage event en otras pestañas
    try { localStorage.removeItem(TOKEN_KEY); } catch (e) {}
    toast({ title: 'Sesión cerrada', description: 'Has cerrado sesión correctamente.' });
    // opcional: redirect; no lo hacemos aquí para mantener control en la app
  }, []);

  const value = {
    user,
    token,
    loading,
    isAuthenticated: !!user && !!token,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
