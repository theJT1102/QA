// src/hooks/useJobs.jsx
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';
import fetchApi from '@/services/api'; // Asume que fetchApi maneja el token internamente
import { useAuth } from './useAuth';

const JobsContext = createContext(null);

export const useJobs = () => {
  const ctx = useContext(JobsContext);
  if (!ctx) throw new Error('useJobs must be used within JobsProvider');
  return ctx;
};

export const JobsProvider = ({ children }) => {
  const [jobs, setJobs] = useState([]); // lista de puestos
  const [applications, setApplications] = useState([]); // lista de postulaciones
  const [loading, setLoading] = useState(false);
  const { user, token } = useAuth(); // Usar token si fetchApi lo requiere explícitamente

  // Normalizers: convierten DTOs del backend a la forma que la UI espera
  const normalizePuestos = (puestos) => {
    if (!Array.isArray(puestos)) return [];
    return puestos.map(p => ({
      id: p.idPuesto ?? p.id,
      title: p.titulo ?? p.title,
      description: p.descripcion ?? p.description,
      requirements: p.requisitosGenerales ?? p.requirements,
      // ASUMO que el backend devuelve el objeto completo de departamento
      department: p.departamento?.nombreDepartamento ?? p.department?.name ?? p.departamento ?? null,
      idDepartamento: p.departamento?.idDepartamento ?? p.idDepartamento ?? null,
      location: p.ubicacion ?? p.location,
      type: p.tipoContrato ?? p.type,
      salary: p.rangoSalarial ?? p.salary,
      status: (p.estado ?? p.status)?.toString()?.toLowerCase() ?? null, // 'pending', 'approved', 'rejected'
      createdBy: {
        id: p.creadoPor?.idUsuario ?? p.creadoPor?.id,
        // ASUMO que el backend mapea el nombre del manager desde PerfilesUsuario o directamente
        username: p.creadoPor?.perfil?.nombreCompleto ?? p.creadoPor?.nombreCompleto ?? p.creadoPor?.email ?? null,
        email: p.creadoPor?.email ?? null
      },
      fechaCreacion: p.fechaCreacion ?? p.fecha,
      habilidadesRequeridas: p.habilidadesRequeridas ?? []
    }));
  };

  const normalizePostulaciones = (postulaciones) => {
    if (!Array.isArray(postulaciones)) return [];
    return postulaciones.map(a => ({
      id: a.idPostulacion ?? a.id,
      candidate: {
        id: a.candidato?.idUsuario ?? a.candidato?.id,
        username: a.candidato?.perfil?.nombreCompleto ?? a.candidato?.nombreCompleto ?? a.candidato?.email,
        email: a.candidato?.email ?? null
      },
      job: {
        id: a.puesto?.idPuesto ?? a.puesto?.id,
        title: a.puesto?.titulo ?? a.puesto?.title,
        location: a.puesto?.ubicacion ?? a.puesto?.location,
        department: a.puesto?.departamento?.nombreDepartamento ?? a.puesto?.department
      },
      status: a.estadoActual ?? a.status,
      appliedAt: a.fechaPostulacion ?? a.appliedAt,
      coverLetter: a.cartaPresentacion ?? a.coverLetter,
      messages: a.historial ? a.historial.map(h => ({ id: h.idHistorial, text: h.comentarios, createdAt: h.fechaCambio })) : [],
      cvFileName: a.candidato?.perfil?.urlCvAlmacenado ?? null
    }));
  };
    
  // --- FUNCIÓN PRINCIPAL DE CARGA DE DATOS ---
  const fetchData = useCallback(async (jobStatusFilter = null) => {
    // `jobStatusFilter` se usará solo para HR/MANAGER. Si es null, trae todos.
    setLoading(true);
    try {
      let jobsUrl = '/puestos/publicos';
      let jobsToSet = [];
      let applicationsToSet = [];

      if (user && (user.role === 'hr' || user.role === 'manager')) {
        // Rol HR/MANAGER: usa el endpoint protegido /puestos.
        // Si se pide un filtro específico (ej: pending para ApproveJobs), lo añade.
        jobsUrl = '/puestos' + (jobStatusFilter ? `?estado=${jobStatusFilter}` : '');
        
        const internalPuestos = await fetchApi(jobsUrl, { method: 'GET' });
        jobsToSet = normalizePuestos(internalPuestos.data || []);
        
        // Cargar todas las postulaciones para gestores
        const apps = await fetchApi('/postulaciones', { method: 'GET' });
        applicationsToSet = normalizePostulaciones(apps.data || []);
        
      } else if (user && user.role === 'candidate') {
        // Rol Candidate: Usa el endpoint público y carga sus postulaciones.
        const publicPuestos = await fetchApi(jobsUrl, { method: 'GET' });
        jobsToSet = normalizePuestos(publicPuestos.data || []);
        
        const myApps = await fetchApi('/postulaciones/mis-postulaciones', { method: 'GET' });
        applicationsToSet = normalizePostulaciones(myApps.data || []);
        
      } else {
        // Usuario público/no logeado
        const publicPuestos = await fetchApi(jobsUrl, { method: 'GET' });
        jobsToSet = normalizePuestos(publicPuestos.data || []);
        applicationsToSet = [];
      }

      setJobs(jobsToSet);
      setApplications(applicationsToSet);

    } catch (err) {
      console.error('Error loading jobs/applications', err);
      toast({ title: 'Error', description: err.message || 'No se pudieron cargar los datos', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [user, token]); // Dependencia del usuario y token

  useEffect(() => {
    // Carga inicial: Solo puestos públicos o aprobados
    fetchData('approved'); // Por defecto carga los aprobados para la página pública
  }, [fetchData]);

  // ------------------------------------------------------------------
  // Funciones de Mutación
  // ------------------------------------------------------------------

  // Crear puesto: POST /puestos expects CrearPuestoDTO
  const createJob = async (jobData) => {
    const payload = {
      // Aseguramos que el DTO reciba idDepartamento
      titulo: jobData.title,
      descripcion: jobData.description,
      requisitosGenerales: jobData.requirements || '',
      idDepartamento: jobData.departmentId, // De CreateJob.jsx (el número)
      ubicacion: jobData.location,
      tipoContrato: jobData.type,
      rangoSalarial: jobData.salary || null,
      // habilidadesRequeridas: se omiten por simplicidad si no se usan aún
    };
    const created = await fetchApi('/puestos', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    return created;
  };

  // Aplicar a puesto: POST /postulaciones
  const applyToJob = async (jobId, textData = {}, cvFile = null) => {
    const payload = {
      idPuesto: jobId,
      cartaPresentacion: textData.coverLetter || ''
    };
    const created = await fetchApi('/postulaciones', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    // Refrescar solo las postulaciones del usuario
    if (user?.role === 'candidate') {
      const myApps = await fetchApi('/postulaciones/mis-postulaciones', { method: 'GET' });
      setApplications(normalizePostulaciones(myApps.data || []));
    }
    return created;
  };

  // Actualizar estado de puesto (aprobar/rechazar)
  const updateJobStatus = async (jobId, status) => {
    const accion = status === 'approved' ? 'approve' : (status === 'rejected' ? 'reject' : null);
    if (!accion) throw new Error('Estado inválido para cambio');
    
    const updated = await fetchApi('/puestos/aprobar-rechazar', {
      method: 'PUT',
      body: JSON.stringify({ idPuesto: jobId, accion, comentario: null }),
    });
    // No se usa fetchData aquí, la vista de aprobación debe recargar con su propio filtro
    return updated;
  };

  // Cambiar estado de postulación
  const updateApplicationStatus = async (applicationId, newStatus, message = '') => {
    const payload = {
      idPostulacion: applicationId,
      nuevoEstado: newStatus,
      comentarios: message,
      enviarNotificacion: true
    };
    const updated = await fetchApi('/postulaciones/cambiar-estado', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
    // Refrescar la lista de postulaciones para managers/hr
    if (user?.role === 'manager' || user?.role === 'hr') {
      const apps = await fetchApi('/postulaciones', { method: 'GET' });
      setApplications(normalizePostulaciones(apps.data || []));
    }
    return updated;
  };

  const value = {
    jobs,
    applications,
    loading,
    fetchData, // Exportamos fetchData para que ApproveJobs pueda llamar a fetchData('pending')
    applyToJob,
    createJob,
    updateJobStatus,
    updateApplicationStatus,
  };

  return <JobsContext.Provider value={value}>{children}</JobsContext.Provider>;
};