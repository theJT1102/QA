import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useJobs } from '@/hooks/useJobs'; 
import { useAuth } from '@/hooks/useAuth';
import { toast } from '@/components/ui/use-toast';
import { CheckCircle, XCircle, Clock, AlertTriangle, Loader2, MapPin, Building, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';

const ApproveJobs = () => {
    // Desestructuración necesaria: 'fetchData' para la carga inicial/refresco.
    const { jobs, updateJobStatus, fetchData, loading } = useJobs(); 
    const { user } = useAuth();
    
    // Estado de carga local para manejar el fetch específico de esta vista.
    const [localLoading, setLocalLoading] = useState(false);
    
    // Función optimizada para cargar solo los trabajos pendientes.
    const loadPendingJobs = useCallback(async () => {
        if (user?.role !== 'hr') return;
        setLocalLoading(true);
        try {
            // Llama al hook para cargar puestos con estado 'pending'
            await fetchData('pending'); 
        } catch (error) {
            toast({
                title: 'Error de Carga',
                description: 'No se pudieron cargar los puestos pendientes.',
                variant: 'destructive',
            });
        } finally {
            setLocalLoading(false);
        }
    }, [user, fetchData]);

    // Ejecutar la carga al montar el componente (sólo una vez).
    useEffect(() => {
        loadPendingJobs();
    }, [loadPendingJobs]);

    // Filtra la lista global 'jobs' para obtener solo los pendientes
    // (aunque fetchData('pending') ya debería haber filtrado en el hook).
    const pendingJobs = jobs.filter(job => job.status === 'pending');
    
    // --- Manejadores de Acción ---

    const handleApprove = async (jobId) => {
        try {
            await updateJobStatus(jobId, 'approved');
            toast({
                title: '¡Trabajo Aprobado!',
                description: 'El trabajo ha sido aprobado y ahora está visible para los candidatos.',
                className: 'bg-green-100 border-green-300 text-green-700',
            });
            // Recarga la lista para que el puesto aprobado desaparezca
            await loadPendingJobs();
        } catch (error) {
            toast({
                title: 'Error',
                description: error.message || 'No se pudo aprobar el trabajo.',
                variant: 'destructive',
            });
        }
    };

    const handleReject = async (jobId) => {
        try {
            await updateJobStatus(jobId, 'rejected');
            toast({
                title: 'Trabajo Rechazado',
                description: 'La solicitud de trabajo ha sido rechazada.',
                variant: 'destructive'
            });
            // Recarga la lista para que el puesto rechazado desaparezca
            await loadPendingJobs();
        } catch (error) {
            toast({
                title: 'Error',
                description: error.message || 'No se pudo rechazar el trabajo.',
                variant: 'destructive',
            });
        }
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'Fecha no disponible';
        return new Date(dateString).toLocaleDateString('es-ES', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
    };

    // --- Lógica de Renderizado de Control ---

    if (user?.role !== 'hr') {
        return (
            <div className="text-center py-12">
                <Card className="bg-card border-border p-8 shadow-lg max-w-md mx-auto">
                    <AlertTriangle className="w-16 h-16 text-destructive mx-auto mb-4" />
                    <CardTitle className="text-destructive text-2xl mb-2">Acceso Denegado</CardTitle>
                    <CardDescription className="text-muted-foreground">
                        Solo el personal de RRHH de SODIMAC puede acceder a esta página.
                    </CardDescription>
                </Card>
            </div>
        );
    }

    if (loading || localLoading) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh]">
                <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
                <p className="text-lg text-muted-foreground">Cargando solicitudes...</p>
            </div>
        );
    }
    
    // --- Renderizado Principal ---
    return (
        <div className="space-y-8">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-center space-y-4">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto shadow-md">
                    <CheckCircle className="w-8 h-8 text-primary-foreground" />
                </div>
                <h1 className="text-4xl font-bold text-foreground">Aprobar Solicitudes de Trabajo</h1>
                <p className="text-xl text-muted-foreground">Revisa y aprueba las nuevas vacantes solicitadas.</p>
            </motion.div>

            {pendingJobs.length === 0 ? (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.2 }} className="text-center py-12">
                    <Card className="bg-card border-border p-8 shadow-lg max-w-md mx-auto">
                        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                        <CardTitle className="text-foreground text-2xl mb-2">Todo al día</CardTitle>
                        <CardDescription className="text-muted-foreground">
                            No hay trabajos pendientes de aprobación en este momento.
                        </CardDescription>
                    </Card>
                </motion.div>
            ) : (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.2 }} className="grid gap-6">
                    {pendingJobs.map((job, index) => (
                        <motion.div key={job.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.05 }}>
                            <Card className="bg-card border-border hover:shadow-xl transition-all duration-300 card-hover">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-foreground text-xl">{job.title}</CardTitle>
                                            <CardDescription className="text-muted-foreground mt-1">
                                                Solicitado por: {job.createdBy?.nombreCompleto || 'N/A'} ({job.createdBy?.email || 'N/A'})
                                            </CardDescription>
                                        </div>
                                        <Badge className="bg-yellow-100 text-yellow-700 border border-yellow-300 font-semibold">
                                            <Clock className="w-3 h-3 mr-1" />
                                            Pendiente de Aprobación
                                        </Badge>
                                    </div>
                                </CardHeader>
                                
                                <CardContent className="space-y-6">
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-muted-foreground">
                                        {/* Nota: Asumo que job.department/location/type/salary son strings simples del DTO */}
                                        <div className="flex items-center space-x-2"><Building className="w-4 h-4 text-primary" /><span>{job.department.nombreDepartamento || job.department}</span></div>
                                        <div className="flex items-center space-x-2"><MapPin className="w-4 h-4 text-primary" /><span>{job.ubicacion}</span></div>
                                        <div className="flex items-center space-x-2"><Clock className="w-4 h-4 text-primary" /><span>{job.tipoContrato}</span></div>
                                        <div className="flex items-center space-x-2"><DollarSign className="w-4 h-4 text-primary" /><span>{job.rangoSalarial || 'No especificado'}</span></div>
                                    </div>
                                    <div className="space-y-3">
                                        <div>
                                            <span className="text-foreground text-sm font-medium">Descripción del Puesto:</span>
                                            <p className="text-muted-foreground text-sm mt-1 leading-relaxed bg-input rounded-lg p-3 border border-border">{job.descripcion}</p>
                                        </div>
                                        {job.requisitosGenerales && (
                                            <div>
                                                <span className="text-foreground text-sm font-medium">Requisitos:</span>
                                                <p className="text-muted-foreground text-sm mt-1 bg-input rounded-lg p-3 border border-border">{job.requisitosGenerales}</p>
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex gap-4 pt-4 border-t border-border">
                                        <Button onClick={() => handleApprove(job.idPuesto)} className="flex-1 bg-green-600 hover:bg-green-700 text-white">
                                            <CheckCircle className="w-4 h-4 mr-2" />Aprobar Trabajo
                                        </Button>
                                        <Button onClick={() => handleReject(job.idPuesto)} variant="destructive" className="flex-1">
                                            <XCircle className="w-4 h-4 mr-2" />Rechazar Solicitud
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </motion.div>
            )}
        </div>
    );
};

export default ApproveJobs;