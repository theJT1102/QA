// src/pages/Register.jsx
import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

const Register = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    nombreCompleto: "",
    email: "",
    password: "",
    confirmPassword: "",
    telefono: "",
    direccion: "",
    rol: "candidate"
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (key) => (e) =>
    setForm((s) => ({ ...s, [key]: e.target.value }));

  const validate = () => {
    if (!form.nombreCompleto || !form.email || !form.password || !form.confirmPassword) {
      setError("Completa los campos obligatorios.");
      return false;
    }
    if (form.password !== form.confirmPassword) {
      setError("Las contraseñas no coinciden.");
      return false;
    }
    if (form.password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres.");
      return false;
    }
    setError("");
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    setError("");

    const payload = {
      nombreCompleto: form.nombreCompleto,
      email: form.email,
      password: form.password,
      telefono: form.telefono,
      direccion: form.direccion,
      rol: form.rol
    };

    try {
      const res = await fetch("http://localhost:8080/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        // Si usas cookies HttpOnly en el backend descomenta la siguiente línea:
        // credentials: "include",
        body: JSON.stringify(payload),
        mode: "cors"
      });

      if (!res.ok) {
        // intenta leer JSON de error, si no, leer texto
        let message = await res.text();
        try {
          const json = JSON.parse(message);
          message = json.message || json.error || JSON.stringify(json);
        } catch (_) {}
        throw new Error(message || `Error ${res.status}`);
      }

      const data = await res.json();
      // backend debe devolver { token: "...", tipo: "Bearer", ... }
      if (data.token) {
        // Almacenamiento simple para desarrollo: localStorage
        localStorage.setItem("authToken", data.token);
        // si prefieres sessionStorage: sessionStorage.setItem("authToken", data.token);
      }

      // navegar al login o dashboard según flujo
      navigate("/login");
    } catch (err) {
      console.error("Fetch error from register:", err);
      setError(err.message || "Error al registrar");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white rounded shadow p-6">
        <h2 className="text-2xl mb-4">Crear cuenta</h2>

        {error && <div className="mb-4 text-red-600">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm">Nombre completo *</label>
            <input
              value={form.nombreCompleto}
              onChange={handleChange("nombreCompleto")}
              className="w-full border px-3 py-2"
              placeholder="Tu nombre completo"
            />
          </div>

          <div>
            <label className="block text-sm">Email *</label>
            <input
              type="email"
              value={form.email}
              onChange={handleChange("email")}
              className="w-full border px-3 py-2"
              placeholder="tu@email.com"
            />
          </div>

          <div>
            <label className="block text-sm">Teléfono</label>
            <input
              value={form.telefono}
              onChange={handleChange("telefono")}
              className="w-full border px-3 py-2"
              placeholder="Ej: 987654321"
            />
          </div>

          <div>
            <label className="block text-sm">Dirección</label>
            <input
              value={form.direccion}
              onChange={handleChange("direccion")}
              className="w-full border px-3 py-2"
              placeholder="Dirección (opcional)"
            />
          </div>

          <div>
            <label className="block text-sm">Contraseña *</label>
            <input
              type="password"
              value={form.password}
              onChange={handleChange("password")}
              className="w-full border px-3 py-2"
              placeholder="Mínimo 6 caracteres"
            />
          </div>

          <div>
            <label className="block text-sm">Confirmar contraseña *</label>
            <input
              type="password"
              value={form.confirmPassword}
              onChange={handleChange("confirmPassword")}
              className="w-full border px-3 py-2"
              placeholder="Repite la contraseña"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded"
          >
            {loading ? "Creando..." : "Crear cuenta"}
          </button>
        </form>

        <p className="mt-4 text-sm">
          ¿Ya tienes cuenta? <Link to="/login" className="text-blue-600">Inicia sesión</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;