package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class ActualizarPerfilDTO {
    private String nombreCompleto;
    private String telefono;
    private String direccion;

    public ActualizarPerfilDTO() {}

    public ActualizarPerfilDTO(String nombreCompleto, String telefono, String direccion) {
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ActualizarPerfilDTO)) return false;
        ActualizarPerfilDTO that = (ActualizarPerfilDTO) o;
        return Objects.equals(nombreCompleto, that.nombreCompleto) &&
               Objects.equals(telefono, that.telefono) &&
               Objects.equals(direccion, that.direccion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreCompleto, telefono, direccion);
    }

    @Override
    public String toString() {
        return "ActualizarPerfilDTO{" +
                "nombreCompleto='" + nombreCompleto + '\'' +
                ", telefono='" + telefono + '\'' +
                ", direccion='" + direccion + '\'' +
                '}';
    }
}