package com.sodimac.portalempleo.service;

import com.sodimac.portalempleo.dto.AprobarRechazarPuestoDTO;
import com.sodimac.portalempleo.dto.CrearPuestoDTO;
import com.sodimac.portalempleo.dto.DepartamentoDTO;
import com.sodimac.portalempleo.dto.HabilidadRequeridaDTO;
import com.sodimac.portalempleo.dto.PuestoSimpleDTO;
import com.sodimac.portalempleo.dto.PuestoTrabajoDTO;
import com.sodimac.portalempleo.dto.UsuarioSimpleDTO;
import com.sodimac.portalempleo.entity.Departamento;
import com.sodimac.portalempleo.entity.Habilidad;
import com.sodimac.portalempleo.entity.HabilidadRequeridaPuesto;
import com.sodimac.portalempleo.entity.HabilidadRequeridaPuestoId;
import com.sodimac.portalempleo.entity.PerfilUsuario;
import com.sodimac.portalempleo.entity.PuestoTrabajo;
import com.sodimac.portalempleo.entity.Usuario;
import com.sodimac.portalempleo.repository.DepartamentoRepository;
import com.sodimac.portalempleo.repository.HabilidadRequeridaPuestoRepository;
import com.sodimac.portalempleo.repository.HabilidadRepository;
import com.sodimac.portalempleo.repository.PuestoTrabajoRepository;
import com.sodimac.portalempleo.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PuestoTrabajoService {

    private final PuestoTrabajoRepository puestoRepository;
    private final DepartamentoRepository departamentoRepository;
    private final UsuarioRepository usuarioRepository;
    private final HabilidadRepository habilidadRepository;
    private final HabilidadRequeridaPuestoRepository habilidadRequeridaRepository;

    public PuestoTrabajoService(PuestoTrabajoRepository puestoRepository,
                                DepartamentoRepository departamentoRepository,
                                UsuarioRepository usuarioRepository,
                                HabilidadRepository habilidadRepository,
                                HabilidadRequeridaPuestoRepository habilidadRequeridaRepository) {
        this.puestoRepository = puestoRepository;
        this.departamentoRepository = departamentoRepository;
        this.usuarioRepository = usuarioRepository;
        this.habilidadRepository = habilidadRepository;
        this.habilidadRequeridaRepository = habilidadRequeridaRepository;
    }

    @Transactional
    public PuestoTrabajoDTO crearPuesto(Integer idUsuarioCreador, CrearPuestoDTO request) {
        Usuario creador = usuarioRepository.findById(idUsuarioCreador)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Departamento departamento = departamentoRepository.findById(request.getIdDepartamento())
                .orElseThrow(() -> new RuntimeException("Departamento no encontrado"));

        PuestoTrabajo puesto = new PuestoTrabajo();
        puesto.setTitulo(request.getTitulo());
        puesto.setDescripcion(request.getDescripcion());
        puesto.setRequisitosGenerales(request.getRequisitosGenerales());
        puesto.setDepartamento(departamento);
        puesto.setUbicacion(request.getUbicacion());
        puesto.setTipoContrato(convertirTipoContrato(request.getTipoContrato()));
        puesto.setRangoSalarial(request.getRangoSalarial());
        puesto.setEstado("pending");
        puesto.setCreadoPor(creador);

        puesto = puestoRepository.save(puesto);

        if (request.getHabilidadesRequeridas() != null) {
            for (HabilidadRequeridaDTO habDTO : request.getHabilidadesRequeridas()) {
                Habilidad habilidad = habilidadRepository.findById(habDTO.getIdHabilidad())
                        .orElseThrow(() -> new RuntimeException("Habilidad no encontrada"));

                HabilidadRequeridaPuesto habRequerida = new HabilidadRequeridaPuesto();
                habRequerida.setId(new HabilidadRequeridaPuestoId(puesto.getIdPuesto(), habilidad.getIdHabilidad()));
                habRequerida.setPuesto(puesto);
                habRequerida.setHabilidad(habilidad);
                habRequerida.setObligatorio(habDTO.getObligatorio());

                habilidadRequeridaRepository.save(habRequerida);
            }
        }

        return convertirAPuestoDTO(puesto);
    }

    public List<PuestoTrabajoDTO> listarPuestosAprobados() {
        // Simplemente llama al método general con el estado deseado
        return listarPuestosPorEstado("approved"); 
    }

    public List<PuestoTrabajoDTO> listarPuestosPorEstado(String estado) {
                
        // ... el resto del código es correcto
    	return puestoRepository.findByEstado(estado.toLowerCase()).stream() 
                .map(this::convertirAPuestoDTO)
                .collect(Collectors.toList());
    }

    public PuestoTrabajoDTO obtenerPuestoPorId(Integer idPuesto) {
        PuestoTrabajo puesto = puestoRepository.findById(idPuesto)
                .orElseThrow(() -> new RuntimeException("Puesto no encontrado"));
        return convertirAPuestoDTO(puesto);
    }

    @Transactional
    public PuestoTrabajoDTO aprobarRechazarPuesto(AprobarRechazarPuestoDTO request) {
        PuestoTrabajo puesto = puestoRepository.findById(request.getIdPuesto())
                .orElseThrow(() -> new RuntimeException("Puesto no encontrado"));

        if ("approve".equalsIgnoreCase(request.getAccion())) {
            puesto.setEstado("approved");
        } else if ("reject".equalsIgnoreCase(request.getAccion())) {
            puesto.setEstado("rejected");
        } else {
            throw new RuntimeException("Acción inválida");
        }

        puesto = puestoRepository.save(puesto);
        return convertirAPuestoDTO(puesto);
    }

    private PuestoTrabajo.TipoContrato convertirTipoContrato(String tipo) {
        if ("Full-time".equalsIgnoreCase(tipo)) return PuestoTrabajo.TipoContrato.FULL_TIME;
        if ("Part-time".equalsIgnoreCase(tipo)) return PuestoTrabajo.TipoContrato.PART_TIME;
        if ("Freelance".equalsIgnoreCase(tipo)) return PuestoTrabajo.TipoContrato.FREELANCE;
        throw new RuntimeException("Tipo de contrato inválido");
    }

    private PuestoTrabajoDTO convertirAPuestoDTO(PuestoTrabajo puesto) {
        List<HabilidadRequeridaDTO> habilidades = habilidadRequeridaRepository
                .findByPuesto_IdPuesto(puesto.getIdPuesto()).stream()
                .map(hr -> new HabilidadRequeridaDTO(
                        hr.getHabilidad().getIdHabilidad(),
                        hr.getHabilidad().getNombreHabilidad(),
                        hr.getObligatorio()
                ))
                .collect(Collectors.toList());

        PerfilUsuario perfil = puesto.getCreadoPor() != null ? puesto.getCreadoPor().getPerfil() : null;

        DepartamentoDTO departamentoDTO = new DepartamentoDTO(
                puesto.getDepartamento().getIdDepartamento(),
                puesto.getDepartamento().getNombreDepartamento()
        );

        UsuarioSimpleDTO creadoPorDTO = new UsuarioSimpleDTO(
                puesto.getCreadoPor().getIdUsuario(),
                puesto.getCreadoPor().getEmail(),
                perfil != null ? perfil.getNombreCompleto() : ""
        );

        PuestoSimpleDTO puestoSimple = new PuestoSimpleDTO(
                puesto.getIdPuesto(),
                puesto.getTitulo(),
                puesto.getUbicacion(),
                puesto.getTipoContrato() != null ? puesto.getTipoContrato().name() : null,
                puesto.getEstado()
        );

        return new PuestoTrabajoDTO(
                puesto.getIdPuesto(),
                puesto.getTitulo(),
                puesto.getDescripcion(),
                puesto.getRequisitosGenerales(),
                departamentoDTO,
                puesto.getUbicacion(),
                puesto.getTipoContrato() != null ? puesto.getTipoContrato().name() : null,
                puesto.getRangoSalarial(),
                puesto.getEstado(),
                creadoPorDTO,
                puesto.getFechaCreacion(),
                habilidades
        );
    }
}