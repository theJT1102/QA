package com.sodimac.portalempleo.entity;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import jakarta.persistence.*;

@Entity
@Table(name = "Postulaciones",
       uniqueConstraints = @UniqueConstraint(columnNames = {"id_candidato", "id_puesto"}))
public class Postulacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_postulacion")
    private Integer idPostulacion;

    @ManyToOne
    @JoinColumn(name = "id_candidato", nullable = false)
    private Usuario candidato;

    @ManyToOne
    @JoinColumn(name = "id_puesto", nullable = false)
    private PuestoTrabajo puesto;

    @Column(name = "fecha_postulacion")
    private LocalDateTime fechaPostulacion;

    @Column(name = "estado_actual", nullable = false, length = 50)
    private String estadoActual;

    @Column(name = "carta_presentacion", columnDefinition = "TEXT")
    private String cartaPresentacion;

    @OneToMany(mappedBy = "postulacion", cascade = CascadeType.ALL)
    private Set<HistorialPostulacion> historial = new HashSet<>();

    public Postulacion() {}

    public Postulacion(Integer idPostulacion, Usuario candidato, PuestoTrabajo puesto,
                       LocalDateTime fechaPostulacion, String estadoActual,
                       String cartaPresentacion, Set<HistorialPostulacion> historial) {
        this.idPostulacion = idPostulacion;
        this.candidato = candidato;
        this.puesto = puesto;
        this.fechaPostulacion = fechaPostulacion;
        this.estadoActual = estadoActual;
        this.cartaPresentacion = cartaPresentacion;
        this.historial = historial != null ? historial : new HashSet<>();
    }

    public Integer getIdPostulacion() { return idPostulacion; }
    public void setIdPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; }

    public Usuario getCandidato() { return candidato; }
    public void setCandidato(Usuario candidato) { this.candidato = candidato; }

    public PuestoTrabajo getPuesto() { return puesto; }
    public void setPuesto(PuestoTrabajo puesto) { this.puesto = puesto; }

    public LocalDateTime getFechaPostulacion() { return fechaPostulacion; }
    public void setFechaPostulacion(LocalDateTime fechaPostulacion) { this.fechaPostulacion = fechaPostulacion; }

    public String getEstadoActual() { return estadoActual; }
    public void setEstadoActual(String estadoActual) { this.estadoActual = estadoActual; }

    public String getCartaPresentacion() { return cartaPresentacion; }
    public void setCartaPresentacion(String cartaPresentacion) { this.cartaPresentacion = cartaPresentacion; }

    public Set<HistorialPostulacion> getHistorial() { return historial; }
    public void setHistorial(Set<HistorialPostulacion> historial) {
        this.historial = historial != null ? historial : new HashSet<>();
    }

    @PrePersist
    protected void onCreate() {
        if (fechaPostulacion == null) {
            fechaPostulacion = LocalDateTime.now();
        }
        if (estadoActual == null) {
            estadoActual = "submitted";
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Postulacion)) return false;
        Postulacion that = (Postulacion) o;
        return Objects.equals(idPostulacion, that.idPostulacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPostulacion);
    }

    @Override
    public String toString() {
        return "Postulacion{" +
                "idPostulacion=" + idPostulacion +
                ", candidato=" + (candidato != null ? candidato.getIdUsuario() : null) +
                ", puesto=" + (puesto != null ? puesto.getIdPuesto() : null) +
                ", fechaPostulacion=" + fechaPostulacion +
                ", estadoActual='" + estadoActual + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idPostulacion;
        private Usuario candidato;
        private PuestoTrabajo puesto;
        private LocalDateTime fechaPostulacion;
        private String estadoActual;
        private String cartaPresentacion;
        private Set<HistorialPostulacion> historial;

        public Builder idPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; return this; }
        public Builder candidato(Usuario candidato) { this.candidato = candidato; return this; }
        public Builder puesto(PuestoTrabajo puesto) { this.puesto = puesto; return this; }
        public Builder fechaPostulacion(LocalDateTime fechaPostulacion) { this.fechaPostulacion = fechaPostulacion; return this; }
        public Builder estadoActual(String estadoActual) { this.estadoActual = estadoActual; return this; }
        public Builder cartaPresentacion(String cartaPresentacion) { this.cartaPresentacion = cartaPresentacion; return this; }
        public Builder historial(Set<HistorialPostulacion> historial) { this.historial = historial; return this; }

        public Postulacion build() {
            return new Postulacion(idPostulacion, candidato, puesto, fechaPostulacion, estadoActual, cartaPresentacion, historial);
        }
    }
}