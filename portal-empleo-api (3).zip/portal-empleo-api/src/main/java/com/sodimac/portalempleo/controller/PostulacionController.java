package com.sodimac.portalempleo.controller;

import com.sodimac.portalempleo.dto.ApiResponse;
import com.sodimac.portalempleo.dto.CambiarEstadoPostulacionDTO;
import com.sodimac.portalempleo.dto.CrearPostulacionDTO;
import com.sodimac.portalempleo.dto.HistorialPostulacionDTO;
import com.sodimac.portalempleo.dto.PostulacionDTO;
import com.sodimac.portalempleo.security.UserDetailsImpl;
import com.sodimac.portalempleo.service.PostulacionService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postulaciones")
public class PostulacionController {

    private final PostulacionService postulacionService;
    private final Logger log = LoggerFactory.getLogger(PostulacionController.class);

    public PostulacionController(PostulacionService postulacionService) {
        this.postulacionService = postulacionService;
    }

    @PostMapping
    @PreAuthorize("hasRole('CANDIDATE')")
    public ResponseEntity<ApiResponse<PostulacionDTO>> crearPostulacion(
            Authentication authentication,
            @Valid @RequestBody CrearPostulacionDTO request) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            PostulacionDTO postulacion = postulacionService.crearPostulacion(userDetails.getId(), request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(postulacion, "Postulación enviada exitosamente"));
        } catch (Exception e) {
            log.error("Error creando postulacion", e);
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    /**
     * GET raíz: devuelve postulaciones según el rol del usuario autenticado.
     * - HR: todas las postulaciones
     * - MANAGER: postulaciones relevantes para el manager (implementación en servicio)
     * - CANDIDATE: solo las del candidato autenticado
     *
     * Asegura que el frontend pueda llamar GET /api/postulaciones sin provocar 405/500.
     */
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<PostulacionDTO>>> listarPostulaciones(Authentication authentication) {
        try {
            if (authentication == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(ApiResponse.error("Usuario no autenticado"));
            }

            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            List<PostulacionDTO> postulaciones;

            boolean isHr = userDetails.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().contains("HR"));
            boolean isManager = userDetails.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().contains("MANAGER"));
            boolean isCandidate = userDetails.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().contains("CANDIDATE"));

            if (isHr) {
                postulaciones = postulacionService.listarTodas();
            } else if (isManager) {
                postulaciones = postulacionService.listarParaManager(userDetails.getId());
            } else if (isCandidate) {
                postulaciones = postulacionService.listarPostulacionesCandidato(userDetails.getId());
            } else {
                // rol desconocido: devolver vacío o 403 según política; aquí devolvemos vacío con mensaje
                postulaciones = List.of();
            }

            return ResponseEntity.ok(ApiResponse.success(postulaciones, "Postulaciones obtenidas"));
        } catch (Exception e) {
            log.error("Error al listar postulaciones", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error interno al obtener postulaciones: " + e.getMessage()));
        }
    }

    @GetMapping("/mis-postulaciones")
    @PreAuthorize("hasRole('CANDIDATE')")
    public ResponseEntity<ApiResponse<List<PostulacionDTO>>> listarMisPostulaciones(
            Authentication authentication) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            List<PostulacionDTO> postulaciones = postulacionService.listarPostulacionesCandidato(userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success(postulaciones, "Postulaciones obtenidas"));
        } catch (Exception e) {
            log.error("Error listando mis postulaciones", e);
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/puesto/{idPuesto}")
    @PreAuthorize("hasAnyRole('MANAGER','HR')")
    public ResponseEntity<ApiResponse<List<PostulacionDTO>>> listarPostulacionesPorPuesto(
            @PathVariable Integer idPuesto) {
        try {
            List<PostulacionDTO> postulaciones = postulacionService.listarPostulacionesPorPuesto(idPuesto);
            return ResponseEntity.ok(ApiResponse.success(postulaciones, "Postulaciones obtenidas"));
        } catch (Exception e) {
            log.error("Error listando postulaciones por puesto", e);
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<PostulacionDTO>> obtenerPostulacion(@PathVariable Integer id) {
        try {
            PostulacionDTO postulacion = postulacionService.obtenerPostulacion(id);
            return ResponseEntity.ok(ApiResponse.success(postulacion, "Postulación obtenida"));
        } catch (Exception e) {
            log.error("Error obteniendo postulacion id={}", id, e);
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @PutMapping("/cambiar-estado")
    @PreAuthorize("hasAnyRole('MANAGER','HR')")
    public ResponseEntity<ApiResponse<PostulacionDTO>> cambiarEstado(
            Authentication authentication,
            @Valid @RequestBody CambiarEstadoPostulacionDTO request) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            PostulacionDTO postulacion = postulacionService.cambiarEstado(userDetails.getId(), request);
            return ResponseEntity.ok(ApiResponse.success(postulacion, "Estado actualizado"));
        } catch (Exception e) {
            log.error("Error cambiando estado de postulacion", e);
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/{id}/historial")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<HistorialPostulacionDTO>>> obtenerHistorial(
            @PathVariable Integer id) {
        try {
            List<HistorialPostulacionDTO> historial = postulacionService.obtenerHistorial(id);
            return ResponseEntity.ok(ApiResponse.success(historial, "Historial obtenido"));
        } catch (Exception e) {
            log.error("Error obteniendo historial postulacion id={}", id, e);
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
}