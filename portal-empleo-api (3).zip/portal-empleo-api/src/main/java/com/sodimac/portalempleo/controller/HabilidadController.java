package com.sodimac.portalempleo.controller;

import com.sodimac.portalempleo.dto.*;
import com.sodimac.portalempleo.security.UserDetailsImpl;
import com.sodimac.portalempleo.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/habilidades")
@RequiredArgsConstructor
public class HabilidadController {
    
    private final HabilidadService habilidadService;
    
    public HabilidadController(HabilidadService habilidadService) {
        this.habilidadService = habilidadService;
    }
    
    @GetMapping
    public ResponseEntity<ApiResponse<List<HabilidadDTO>>> listarHabilidades(
            @RequestParam(required = false) String buscar) {
        try {
            List<HabilidadDTO> habilidades;
            if (buscar != null && !buscar.isEmpty()) {
                habilidades = habilidadService.buscarHabilidades(buscar);
            } else {
                habilidades = habilidadService.listarTodasHabilidades();
            }
            return ResponseEntity.ok(ApiResponse.success(habilidades, "Habilidades obtenidas"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
    
    @PostMapping
    @PreAuthorize("hasAnyRole('MANAGER', 'HR')")
    public ResponseEntity<ApiResponse<HabilidadDTO>> crearHabilidad(
            @RequestParam String nombreHabilidad) {
        try {
            HabilidadDTO habilidad = habilidadService.crearHabilidad(nombreHabilidad);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(habilidad, "Habilidad creada"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
    
    @GetMapping("/mis-habilidades")
    @PreAuthorize("hasRole('CANDIDATE')")
    public ResponseEntity<ApiResponse<List<HabilidadUsuarioDTO>>> obtenerMisHabilidades(
            Authentication authentication) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            List<HabilidadUsuarioDTO> habilidades = habilidadService.obtenerHabilidadesUsuario(userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success(habilidades, "Habilidades obtenidas"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
    
    @PostMapping("/mis-habilidades")
    @PreAuthorize("hasRole('CANDIDATE')")
    public ResponseEntity<ApiResponse<HabilidadUsuarioDTO>> agregarHabilidad(
            Authentication authentication,
            @Valid @RequestBody AgregarHabilidadUsuarioDTO request) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            HabilidadUsuarioDTO habilidad = habilidadService.agregarHabilidadAUsuario(userDetails.getId(), request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(habilidad, "Habilidad agregada"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
    
    @DeleteMapping("/mis-habilidades/{idHabilidad}")
    @PreAuthorize("hasRole('CANDIDATE')")
    public ResponseEntity<ApiResponse<Void>> eliminarHabilidad(
            Authentication authentication,
            @PathVariable Integer idHabilidad) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            habilidadService.eliminarHabilidadDeUsuario(userDetails.getId(), idHabilidad);
            return ResponseEntity.ok(ApiResponse.success(null, "Habilidad eliminada"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
}
