package com.sodimac.portalempleo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;

public class CrearPuestoDTO {
    @NotBlank(message = "El título es requerido")
    private String titulo;

    @NotBlank(message = "La descripción es requerida")
    private String descripcion;

    private String requisitosGenerales;

    @NotNull(message = "El departamento es requerido")
    private Integer idDepartamento;

    @NotBlank(message = "La ubicación es requerida")
    private String ubicacion;

    @NotBlank(message = "El tipo de contrato es requerido")
    private String tipoContrato;

    private String rangoSalarial;

    private List<HabilidadRequeridaDTO> habilidadesRequeridas;

    public CrearPuestoDTO() {}

    public CrearPuestoDTO(String titulo, String descripcion, String requisitosGenerales,
                          Integer idDepartamento, String ubicacion, String tipoContrato,
                          String rangoSalarial, List<HabilidadRequeridaDTO> habilidadesRequeridas) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.requisitosGenerales = requisitosGenerales;
        this.idDepartamento = idDepartamento;
        this.ubicacion = ubicacion;
        this.tipoContrato = tipoContrato;
        this.rangoSalarial = rangoSalarial;
        this.habilidadesRequeridas = habilidadesRequeridas;
    }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getRequisitosGenerales() { return requisitosGenerales; }
    public void setRequisitosGenerales(String requisitosGenerales) { this.requisitosGenerales = requisitosGenerales; }

    public Integer getIdDepartamento() { return idDepartamento; }
    public void setIdDepartamento(Integer idDepartamento) { this.idDepartamento = idDepartamento; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public String getTipoContrato() { return tipoContrato; }
    public void setTipoContrato(String tipoContrato) { this.tipoContrato = tipoContrato; }

    public String getRangoSalarial() { return rangoSalarial; }
    public void setRangoSalarial(String rangoSalarial) { this.rangoSalarial = rangoSalarial; }

    public List<HabilidadRequeridaDTO> getHabilidadesRequeridas() { return habilidadesRequeridas; }
    public void setHabilidadesRequeridas(List<HabilidadRequeridaDTO> habilidadesRequeridas) { this.habilidadesRequeridas = habilidadesRequeridas; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CrearPuestoDTO)) return false;
        CrearPuestoDTO that = (CrearPuestoDTO) o;
        return Objects.equals(titulo, that.titulo) &&
               Objects.equals(descripcion, that.descripcion) &&
               Objects.equals(requisitosGenerales, that.requisitosGenerales) &&
               Objects.equals(idDepartamento, that.idDepartamento) &&
               Objects.equals(ubicacion, that.ubicacion) &&
               Objects.equals(tipoContrato, that.tipoContrato) &&
               Objects.equals(rangoSalarial, that.rangoSalarial) &&
               Objects.equals(habilidadesRequeridas, that.habilidadesRequeridas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, descripcion, requisitosGenerales, idDepartamento, ubicacion, tipoContrato, rangoSalarial, habilidadesRequeridas);
    }

    @Override
    public String toString() {
        return "CrearPuestoDTO{" +
                "titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", requisitosGenerales='" + requisitosGenerales + '\'' +
                ", idDepartamento=" + idDepartamento +
                ", ubicacion='" + ubicacion + '\'' +
                ", tipoContrato='" + tipoContrato + '\'' +
                ", rangoSalarial='" + rangoSalarial + '\'' +
                ", habilidadesRequeridas=" + habilidadesRequeridas +
                '}';
    }
}