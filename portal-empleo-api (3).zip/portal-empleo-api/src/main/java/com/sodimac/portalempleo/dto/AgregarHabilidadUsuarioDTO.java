package com.sodimac.portalempleo.dto;

import jakarta.validation.constraints.NotNull;
import java.util.Objects;

public class AgregarHabilidadUsuarioDTO {
    @NotNull
    private Integer idHabilidad;

    private String nivel; // "Básico", "Intermedio", "Avanzado"

    public AgregarHabilidadUsuarioDTO() {}

    public AgregarHabilidadUsuarioDTO(Integer idHabilidad, String nivel) {
        this.idHabilidad = idHabilidad;
        this.nivel = nivel;
    }

    public Integer getIdHabilidad() { return idHabilidad; }
    public void setIdHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; }

    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AgregarHabilidadUsuarioDTO)) return false;
        AgregarHabilidadUsuarioDTO that = (AgregarHabilidadUsuarioDTO) o;
        return Objects.equals(idHabilidad, that.idHabilidad) &&
               Objects.equals(nivel, that.nivel);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHabilidad, nivel);
    }

    @Override
    public String toString() {
        return "AgregarHabilidadUsuarioDTO{" +
                "idHabilidad=" + idHabilidad +
                ", nivel='" + nivel + '\'' +
                '}';
    }
}