package com.sodimac.portalempleo.repository;

import com.sodimac.portalempleo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PerfilUsuarioRepository extends JpaRepository<PerfilUsuario, Integer> {
    Optional<PerfilUsuario> findByUsuario_IdUsuario(Integer idUsuario);
}
