package com.sodimac.portalempleo.dto;

import java.time.LocalDateTime;
import java.util.Objects;

public class PostulacionDTO {
    private Integer idPostulacion;
    private UsuarioSimpleDTO candidato;
    private PuestoSimpleDTO puesto;
    private LocalDateTime fechaPostulacion;
    private String estadoActual;
    private String cartaPresentacion;

    public PostulacionDTO() {}

    public PostulacionDTO(Integer idPostulacion, UsuarioSimpleDTO candidato, PuestoSimpleDTO puesto,
                          LocalDateTime fechaPostulacion, String estadoActual, String cartaPresentacion) {
        this.idPostulacion = idPostulacion;
        this.candidato = candidato;
        this.puesto = puesto;
        this.fechaPostulacion = fechaPostulacion;
        this.estadoActual = estadoActual;
        this.cartaPresentacion = cartaPresentacion;
    }

    public Integer getIdPostulacion() { return idPostulacion; }
    public void setIdPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; }

    public UsuarioSimpleDTO getCandidato() { return candidato; }
    public void setCandidato(UsuarioSimpleDTO candidato) { this.candidato = candidato; }

    public PuestoSimpleDTO getPuesto() { return puesto; }
    public void setPuesto(PuestoSimpleDTO puesto) { this.puesto = puesto; }

    public LocalDateTime getFechaPostulacion() { return fechaPostulacion; }
    public void setFechaPostulacion(LocalDateTime fechaPostulacion) { this.fechaPostulacion = fechaPostulacion; }

    public String getEstadoActual() { return estadoActual; }
    public void setEstadoActual(String estadoActual) { this.estadoActual = estadoActual; }

    public String getCartaPresentacion() { return cartaPresentacion; }
    public void setCartaPresentacion(String cartaPresentacion) { this.cartaPresentacion = cartaPresentacion; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PostulacionDTO)) return false;
        PostulacionDTO that = (PostulacionDTO) o;
        return Objects.equals(idPostulacion, that.idPostulacion) &&
                Objects.equals(candidato, that.candidato) &&
                Objects.equals(puesto, that.puesto) &&
                Objects.equals(fechaPostulacion, that.fechaPostulacion) &&
                Objects.equals(estadoActual, that.estadoActual) &&
                Objects.equals(cartaPresentacion, that.cartaPresentacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPostulacion, candidato, puesto, fechaPostulacion, estadoActual, cartaPresentacion);
    }

    @Override
    public String toString() {
        return "PostulacionDTO{" +
                "idPostulacion=" + idPostulacion +
                ", candidato=" + candidato +
                ", puesto=" + puesto +
                ", fechaPostulacion=" + fechaPostulacion +
                ", estadoActual='" + estadoActual + '\'' +
                ", cartaPresentacion='" + cartaPresentacion + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idPostulacion;
        private UsuarioSimpleDTO candidato;
        private PuestoSimpleDTO puesto;
        private LocalDateTime fechaPostulacion;
        private String estadoActual;
        private String cartaPresentacion;

        public Builder idPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; return this; }
        public Builder candidato(UsuarioSimpleDTO candidato) { this.candidato = candidato; return this; }
        public Builder puesto(PuestoSimpleDTO puesto) { this.puesto = puesto; return this; }
        public Builder fechaPostulacion(LocalDateTime fechaPostulacion) { this.fechaPostulacion = fechaPostulacion; return this; }
        public Builder estadoActual(String estadoActual) { this.estadoActual = estadoActual; return this; }
        public Builder cartaPresentacion(String cartaPresentacion) { this.cartaPresentacion = cartaPresentacion; return this; }

        public PostulacionDTO build() {
            return new PostulacionDTO(idPostulacion, candidato, puesto, fechaPostulacion, estadoActual, cartaPresentacion);
        }
    }
}