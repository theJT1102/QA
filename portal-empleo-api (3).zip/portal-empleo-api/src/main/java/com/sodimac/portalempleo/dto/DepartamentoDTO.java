package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class DepartamentoDTO {
    private Integer idDepartamento;
    private String nombreDepartamento;

    public DepartamentoDTO() {}

    public DepartamentoDTO(Integer idDepartamento, String nombreDepartamento) {
        this.idDepartamento = idDepartamento;
        this.nombreDepartamento = nombreDepartamento;
    }

    public Integer getIdDepartamento() { return idDepartamento; }
    public void setIdDepartamento(Integer idDepartamento) { this.idDepartamento = idDepartamento; }

    public String getNombreDepartamento() { return nombreDepartamento; }
    public void setNombreDepartamento(String nombreDepartamento) { this.nombreDepartamento = nombreDepartamento; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DepartamentoDTO)) return false;
        DepartamentoDTO that = (DepartamentoDTO) o;
        return Objects.equals(idDepartamento, that.idDepartamento) &&
               Objects.equals(nombreDepartamento, that.nombreDepartamento);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idDepartamento, nombreDepartamento);
    }

    @Override
    public String toString() {
        return "DepartamentoDTO{" +
                "idDepartamento=" + idDepartamento +
                ", nombreDepartamento='" + nombreDepartamento + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idDepartamento;
        private String nombreDepartamento;

        public Builder idDepartamento(Integer idDepartamento) { this.idDepartamento = idDepartamento; return this; }
        public Builder nombreDepartamento(String nombreDepartamento) { this.nombreDepartamento = nombreDepartamento; return this; }

        public DepartamentoDTO build() {
            return new DepartamentoDTO(idDepartamento, nombreDepartamento);
        }
    }
}