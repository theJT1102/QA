package com.sodimac.portalempleo.dto;

import java.time.LocalDateTime;
import java.util.Objects;

public class UsuarioDTO {
    private Integer idUsuario;
    private String email;
    private String rol;
    private LocalDateTime fechaRegistro;
    private LocalDateTime ultimoLogin;
    private PerfilUsuarioDTO perfil;

    public UsuarioDTO() {}

    public UsuarioDTO(Integer idUsuario, String email, String rol,
                      LocalDateTime fechaRegistro, LocalDateTime ultimoLogin,
                      PerfilUsuarioDTO perfil) {
        this.idUsuario = idUsuario;
        this.email = email;
        this.rol = rol;
        this.fechaRegistro = fechaRegistro;
        this.ultimoLogin = ultimoLogin;
        this.perfil = perfil;
    }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public LocalDateTime getUltimoLogin() { return ultimoLogin; }
    public void setUltimoLogin(LocalDateTime ultimoLogin) { this.ultimoLogin = ultimoLogin; }

    public PerfilUsuarioDTO getPerfil() { return perfil; }
    public void setPerfil(PerfilUsuarioDTO perfil) { this.perfil = perfil; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UsuarioDTO)) return false;
        UsuarioDTO that = (UsuarioDTO) o;
        return Objects.equals(idUsuario, that.idUsuario)
            && Objects.equals(email, that.email)
            && Objects.equals(rol, that.rol)
            && Objects.equals(fechaRegistro, that.fechaRegistro)
            && Objects.equals(ultimoLogin, that.ultimoLogin)
            && Objects.equals(perfil, that.perfil);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUsuario, email, rol, fechaRegistro, ultimoLogin, perfil);
    }

    @Override
    public String toString() {
        return "UsuarioDTO{" +
                "idUsuario=" + idUsuario +
                ", email='" + email + '\'' +
                ", rol='" + rol + '\'' +
                ", fechaRegistro=" + fechaRegistro +
                ", ultimoLogin=" + ultimoLogin +
                ", perfil=" + perfil +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idUsuario;
        private String email;
        private String rol;
        private LocalDateTime fechaRegistro;
        private LocalDateTime ultimoLogin;
        private PerfilUsuarioDTO perfil;

        public Builder idUsuario(Integer idUsuario) { this.idUsuario = idUsuario; return this; }
        public Builder email(String email) { this.email = email; return this; }
        public Builder rol(String rol) { this.rol = rol; return this; }
        public Builder fechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; return this; }
        public Builder ultimoLogin(LocalDateTime ultimoLogin) { this.ultimoLogin = ultimoLogin; return this; }
        public Builder perfil(PerfilUsuarioDTO perfil) { this.perfil = perfil; return this; }

        public UsuarioDTO build() {
            return new UsuarioDTO(idUsuario, email, rol, fechaRegistro, ultimoLogin, perfil);
        }
    }
}