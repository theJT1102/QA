package com.sodimac.portalempleo.entity;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import jakarta.persistence.*;

@Entity
@Table(name = "Puestostrabajo")
public class PuestoTrabajo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_puesto")
    private Integer idPuesto;

    @Column(nullable = false, length = 150)
    private String titulo;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String descripcion;

    @Column(name = "requisitos_generales", columnDefinition = "TEXT")
    private String requisitosGenerales;

    @ManyToOne
    @JoinColumn(name = "id_departamento", nullable = false)
    private Departamento departamento;

    @Column(nullable = false, length = 100)
    private String ubicacion;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_contrato", nullable = false)
    private TipoContrato tipoContrato;

    @Column(name = "rango_salarial", length = 50)
    private String rangoSalarial;

    
    @Column(nullable = false)
    private String estado;

    @ManyToOne
    @JoinColumn(name = "creado_por_id", nullable = false)
    private Usuario creadoPor;

    @Column(name = "fecha_creacion")
    private LocalDateTime fechaCreacion;

    @OneToMany(mappedBy = "puesto")
    private Set<Postulacion> postulaciones = new HashSet<>();

    @OneToMany(mappedBy = "puesto", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<HabilidadRequeridaPuesto> habilidadesRequeridas = new HashSet<>();

    public PuestoTrabajo() {}

    public PuestoTrabajo(Integer idPuesto, String titulo, String descripcion, String requisitosGenerales,
                         Departamento departamento, String ubicacion, TipoContrato tipoContrato,
                         String rangoSalarial, String estado, Usuario creadoPor, LocalDateTime fechaCreacion,
                         Set<Postulacion> postulaciones, Set<HabilidadRequeridaPuesto> habilidadesRequeridas) {
        this.idPuesto = idPuesto;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.requisitosGenerales = requisitosGenerales;
        this.departamento = departamento;
        this.ubicacion = ubicacion;
        this.tipoContrato = tipoContrato;
        this.rangoSalarial = rangoSalarial;
        this.estado = estado;
        this.creadoPor = creadoPor;
        this.fechaCreacion = fechaCreacion;
        this.postulaciones = postulaciones != null ? postulaciones : new HashSet<>();
        this.habilidadesRequeridas = habilidadesRequeridas != null ? habilidadesRequeridas : new HashSet<>();
    }

    public Integer getIdPuesto() { return idPuesto; }
    public void setIdPuesto(Integer idPuesto) { this.idPuesto = idPuesto; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getRequisitosGenerales() { return requisitosGenerales; }
    public void setRequisitosGenerales(String requisitosGenerales) { this.requisitosGenerales = requisitosGenerales; }

    public Departamento getDepartamento() { return departamento; }
    public void setDepartamento(Departamento departamento) { this.departamento = departamento; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public TipoContrato getTipoContrato() { return tipoContrato; }
    public void setTipoContrato(TipoContrato tipoContrato) { this.tipoContrato = tipoContrato; }

    public String getRangoSalarial() { return rangoSalarial; }
    public void setRangoSalarial(String rangoSalarial) { this.rangoSalarial = rangoSalarial; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public Usuario getCreadoPor() { return creadoPor; }
    public void setCreadoPor(Usuario creadoPor) { this.creadoPor = creadoPor; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public Set<Postulacion> getPostulaciones() { return postulaciones; }
    public void setPostulaciones(Set<Postulacion> postulaciones) {
        this.postulaciones = postulaciones != null ? postulaciones : new HashSet<>();
    }

    public Set<HabilidadRequeridaPuesto> getHabilidadesRequeridas() { return habilidadesRequeridas; }
    public void setHabilidadesRequeridas(Set<HabilidadRequeridaPuesto> habilidadesRequeridas) {
        this.habilidadesRequeridas = habilidadesRequeridas != null ? habilidadesRequeridas : new HashSet<>();
    }

    @PrePersist
    protected void onCreate() {
        if (fechaCreacion == null) {
            fechaCreacion = LocalDateTime.now();
        }
        if (estado == null) {
            estado = "pending";
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PuestoTrabajo)) return false;
        PuestoTrabajo that = (PuestoTrabajo) o;
        return Objects.equals(idPuesto, that.idPuesto);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPuesto);
    }

    @Override
    public String toString() {
        return "PuestoTrabajo{" +
                "idPuesto=" + idPuesto +
                ", titulo='" + titulo + '\'' +
                ", departamento=" + (departamento != null ? departamento.getIdDepartamento() : null) +
                ", ubicacion='" + ubicacion + '\'' +
                ", tipoContrato=" + tipoContrato +
                ", estado=" + estado +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idPuesto;
        private String titulo;
        private String descripcion;
        private String requisitosGenerales;
        private Departamento departamento;
        private String ubicacion;
        private TipoContrato tipoContrato;
        private String rangoSalarial;
        private String estado;
        private Usuario creadoPor;
        private LocalDateTime fechaCreacion;
        private Set<Postulacion> postulaciones;
        private Set<HabilidadRequeridaPuesto> habilidadesRequeridas;

        public Builder idPuesto(Integer idPuesto) { this.idPuesto = idPuesto; return this; }
        public Builder titulo(String titulo) { this.titulo = titulo; return this; }
        public Builder descripcion(String descripcion) { this.descripcion = descripcion; return this; }
        public Builder requisitosGenerales(String requisitosGenerales) { this.requisitosGenerales = requisitosGenerales; return this; }
        public Builder departamento(Departamento departamento) { this.departamento = departamento; return this; }
        public Builder ubicacion(String ubicacion) { this.ubicacion = ubicacion; return this; }
        public Builder tipoContrato(TipoContrato tipoContrato) { this.tipoContrato = tipoContrato; return this; }
        public Builder rangoSalarial(String rangoSalarial) { this.rangoSalarial = rangoSalarial; return this; }
        public Builder estado(String estado) { this.estado = estado; return this; }
        public Builder creadoPor(Usuario creadoPor) { this.creadoPor = creadoPor; return this; }
        public Builder fechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; return this; }
        public Builder postulaciones(Set<Postulacion> postulaciones) { this.postulaciones = postulaciones; return this; }
        public Builder habilidadesRequeridas(Set<HabilidadRequeridaPuesto> habilidadesRequeridas) { this.habilidadesRequeridas = habilidadesRequeridas; return this; }

        public PuestoTrabajo build() {
            return new PuestoTrabajo(idPuesto, titulo, descripcion, requisitosGenerales, departamento, ubicacion,
                    tipoContrato, rangoSalarial, estado, creadoPor, fechaCreacion, postulaciones, habilidadesRequeridas);
        }
    }

    public enum TipoContrato {
        FULL_TIME("Full-time"),
        PART_TIME("Part-time"),
        FREELANCE("Freelance");

        private final String valor;
        TipoContrato(String valor) { this.valor = valor; }
        public String getValor() { return valor; }
    }

    
}
