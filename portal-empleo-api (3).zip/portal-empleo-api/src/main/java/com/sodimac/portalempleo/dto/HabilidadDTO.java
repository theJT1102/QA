package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class HabilidadDTO {
    private Integer idHabilidad;
    private String nombreHabilidad;

    public HabilidadDTO() {}

    public HabilidadDTO(Integer idHabilidad, String nombreHabilidad) {
        this.idHabilidad = idHabilidad;
        this.nombreHabilidad = nombreHabilidad;
    }

    public Integer getIdHabilidad() { return idHabilidad; }
    public void setIdHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; }

    public String getNombreHabilidad() { return nombreHabilidad; }
    public void setNombreHabilidad(String nombreHabilidad) { this.nombreHabilidad = nombreHabilidad; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HabilidadDTO)) return false;
        HabilidadDTO that = (HabilidadDTO) o;
        return Objects.equals(idHabilidad, that.idHabilidad) &&
               Objects.equals(nombreHabilidad, that.nombreHabilidad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHabilidad, nombreHabilidad);
    }

    @Override
    public String toString() {
        return "HabilidadDTO{" +
                "idHabilidad=" + idHabilidad +
                ", nombreHabilidad='" + nombreHabilidad + '\'' +
                '}';
    }
}