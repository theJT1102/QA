package com.sodimac.portalempleo.dto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

public class PuestoTrabajoDTO {
    private Integer idPuesto;
    private String titulo;
    private String descripcion;
    private String requisitosGenerales;
    private DepartamentoDTO departamento;
    private String ubicacion;
    private String tipoContrato;
    private String rangoSalarial;
    private String estado;
    private UsuarioSimpleDTO creadoPor;
    private LocalDateTime fechaCreacion;
    private List<HabilidadRequeridaDTO> habilidadesRequeridas;

    public PuestoTrabajoDTO() {}

    public PuestoTrabajoDTO(Integer idPuesto, String titulo, String descripcion, String requisitosGenerales,
                            DepartamentoDTO departamento, String ubicacion, String tipoContrato,
                            String rangoSalarial, String estado, UsuarioSimpleDTO creadoPor,
                            LocalDateTime fechaCreacion, List<HabilidadRequeridaDTO> habilidadesRequeridas) {
        this.idPuesto = idPuesto;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.requisitosGenerales = requisitosGenerales;
        this.departamento = departamento;
        this.ubicacion = ubicacion;
        this.tipoContrato = tipoContrato;
        this.rangoSalarial = rangoSalarial;
        this.estado = estado;
        this.creadoPor = creadoPor;
        this.fechaCreacion = fechaCreacion;
        this.habilidadesRequeridas = habilidadesRequeridas;
    }

    public Integer getIdPuesto() { return idPuesto; }
    public void setIdPuesto(Integer idPuesto) { this.idPuesto = idPuesto; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getRequisitosGenerales() { return requisitosGenerales; }
    public void setRequisitosGenerales(String requisitosGenerales) { this.requisitosGenerales = requisitosGenerales; }

    public DepartamentoDTO getDepartamento() { return departamento; }
    public void setDepartamento(DepartamentoDTO departamento) { this.departamento = departamento; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public String getTipoContrato() { return tipoContrato; }
    public void setTipoContrato(String tipoContrato) { this.tipoContrato = tipoContrato; }

    public String getRangoSalarial() { return rangoSalarial; }
    public void setRangoSalarial(String rangoSalarial) { this.rangoSalarial = rangoSalarial; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public UsuarioSimpleDTO getCreadoPor() { return creadoPor; }
    public void setCreadoPor(UsuarioSimpleDTO creadoPor) { this.creadoPor = creadoPor; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public List<HabilidadRequeridaDTO> getHabilidadesRequeridas() { return habilidadesRequeridas; }
    public void setHabilidadesRequeridas(List<HabilidadRequeridaDTO> habilidadesRequeridas) { this.habilidadesRequeridas = habilidadesRequeridas; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PuestoTrabajoDTO)) return false;
        PuestoTrabajoDTO that = (PuestoTrabajoDTO) o;
        return Objects.equals(idPuesto, that.idPuesto) &&
                Objects.equals(titulo, that.titulo) &&
                Objects.equals(descripcion, that.descripcion) &&
                Objects.equals(requisitosGenerales, that.requisitosGenerales) &&
                Objects.equals(departamento, that.departamento) &&
                Objects.equals(ubicacion, that.ubicacion) &&
                Objects.equals(tipoContrato, that.tipoContrato) &&
                Objects.equals(rangoSalarial, that.rangoSalarial) &&
                Objects.equals(estado, that.estado) &&
                Objects.equals(creadoPor, that.creadoPor) &&
                Objects.equals(fechaCreacion, that.fechaCreacion) &&
                Objects.equals(habilidadesRequeridas, that.habilidadesRequeridas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPuesto, titulo, descripcion, requisitosGenerales, departamento, ubicacion,
                tipoContrato, rangoSalarial, estado, creadoPor, fechaCreacion, habilidadesRequeridas);
    }

    @Override
    public String toString() {
        return "PuestoTrabajoDTO{" +
                "idPuesto=" + idPuesto +
                ", titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", requisitosGenerales='" + requisitosGenerales + '\'' +
                ", departamento=" + departamento +
                ", ubicacion='" + ubicacion + '\'' +
                ", tipoContrato='" + tipoContrato + '\'' +
                ", rangoSalarial='" + rangoSalarial + '\'' +
                ", estado='" + estado + '\'' +
                ", creadoPor=" + creadoPor +
                ", fechaCreacion=" + fechaCreacion +
                ", habilidadesRequeridas=" + habilidadesRequeridas +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idPuesto;
        private String titulo;
        private String descripcion;
        private String requisitosGenerales;
        private DepartamentoDTO departamento;
        private String ubicacion;
        private String tipoContrato;
        private String rangoSalarial;
        private String estado;
        private UsuarioSimpleDTO creadoPor;
        private LocalDateTime fechaCreacion;
        private List<HabilidadRequeridaDTO> habilidadesRequeridas;

        public Builder idPuesto(Integer idPuesto) { this.idPuesto = idPuesto; return this; }
        public Builder titulo(String titulo) { this.titulo = titulo; return this; }
        public Builder descripcion(String descripcion) { this.descripcion = descripcion; return this; }
        public Builder requisitosGenerales(String requisitosGenerales) { this.requisitosGenerales = requisitosGenerales; return this; }
        public Builder departamento(DepartamentoDTO departamento) { this.departamento = departamento; return this; }
        public Builder ubicacion(String ubicacion) { this.ubicacion = ubicacion; return this; }
        public Builder tipoContrato(String tipoContrato) { this.tipoContrato = tipoContrato; return this; }
        public Builder rangoSalarial(String rangoSalarial) { this.rangoSalarial = rangoSalarial; return this; }
        public Builder estado(String estado) { this.estado = estado; return this; }
        public Builder creadoPor(UsuarioSimpleDTO creadoPor) { this.creadoPor = creadoPor; return this; }
        public Builder fechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; return this; }
        public Builder habilidadesRequeridas(List<HabilidadRequeridaDTO> habilidadesRequeridas) { this.habilidadesRequeridas = habilidadesRequeridas; return this; }

        public PuestoTrabajoDTO build() {
            return new PuestoTrabajoDTO(idPuesto, titulo, descripcion, requisitosGenerales, departamento,
                    ubicacion, tipoContrato, rangoSalarial, estado, creadoPor, fechaCreacion, habilidadesRequeridas);
        }
    }
}