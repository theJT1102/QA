package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class UsuarioSimpleDTO {
    private Integer idUsuario;
    private String email;
    private String nombreCompleto;

    public UsuarioSimpleDTO() {}

    public UsuarioSimpleDTO(Integer idUsuario, String email, String nombreCompleto) {
        this.idUsuario = idUsuario;
        this.email = email;
        this.nombreCompleto = nombreCompleto;
    }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UsuarioSimpleDTO)) return false;
        UsuarioSimpleDTO that = (UsuarioSimpleDTO) o;
        return Objects.equals(idUsuario, that.idUsuario)
                && Objects.equals(email, that.email)
                && Objects.equals(nombreCompleto, that.nombreCompleto);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUsuario, email, nombreCompleto);
    }

    @Override
    public String toString() {
        return "UsuarioSimpleDTO{" +
                "idUsuario=" + idUsuario +
                ", email='" + email + '\'' +
                ", nombreCompleto='" + nombreCompleto + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idUsuario;
        private String email;
        private String nombreCompleto;

        public Builder idUsuario(Integer idUsuario) { this.idUsuario = idUsuario; return this; }
        public Builder email(String email) { this.email = email; return this; }
        public Builder nombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; return this; }

        public UsuarioSimpleDTO build() {
            return new UsuarioSimpleDTO(idUsuario, email, nombreCompleto);
        }
    }
}