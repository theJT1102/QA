package com.sodimac.portalempleo.repository;

import com.sodimac.portalempleo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public interface NotificacionRepository extends JpaRepository<Notificacion, Integer> {
    List<Notificacion> findByUsuarioDestino_IdUsuarioOrderByFechaEnvioDesc(Integer idUsuario);
    List<Notificacion> findByUsuarioDestino_IdUsuarioAndLeidaOrderByFechaEnvioDesc(Integer idUsuario, Boolean leida);
    
    @Query("SELECT COUNT(n) FROM Notificacion n WHERE n.usuarioDestino.idUsuario = :idUsuario AND n.leida = false")
    long countNoLeidasByUsuario(Integer idUsuario);
}