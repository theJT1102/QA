package com.sodimac.portalempleo.entity;

import java.util.Objects;
import jakarta.persistence.*;

@Entity
@Table(name = "Habilidadesusuario")
public class HabilidadUsuario {

    @EmbeddedId
    private HabilidadUsuarioId id;

    @ManyToOne
    @MapsId("idUsuario")
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @ManyToOne
    @MapsId("idHabilidad")
    @JoinColumn(name = "id_habilidad")
    private Habilidad habilidad;

    @Column(length = 50)
    private String nivel; // ejemplo: "basico", "intermedio", "avanzado"

    
    public HabilidadUsuario() {}

    public HabilidadUsuario(HabilidadUsuarioId id, Usuario usuario, Habilidad habilidad, String nivel) {
        this.id = id;
        this.usuario = usuario;
        this.habilidad = habilidad;
        this.nivel = nivel;
            }

    public HabilidadUsuarioId getId() { return id; }
    public void setId(HabilidadUsuarioId id) { this.id = id; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        if (this.id == null && usuario != null && usuario.getIdUsuario() != null) {
            this.id = new HabilidadUsuarioId(usuario.getIdUsuario(), this.id != null ? this.id.getIdHabilidad() : null);
        }
    }

    public Habilidad getHabilidad() { return habilidad; }
    public void setHabilidad(Habilidad habilidad) {
        this.habilidad = habilidad;
        if (this.id == null && habilidad != null && habilidad.getIdHabilidad() != null) {
            this.id = new HabilidadUsuarioId(this.id != null ? this.id.getIdUsuario() : null, habilidad.getIdHabilidad());
        }
    }

    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }

       
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HabilidadUsuario)) return false;
        HabilidadUsuario that = (HabilidadUsuario) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "HabilidadUsuario{" +
                "id=" + id +
                ", usuario=" + (usuario != null ? usuario.getIdUsuario() : null) +
                ", habilidad=" + (habilidad != null ? habilidad.getIdHabilidad() : null) +
                ", nivel='" + nivel + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private HabilidadUsuarioId id;
        private Usuario usuario;
        private Habilidad habilidad;
        private String nivel;
        

        public Builder id(HabilidadUsuarioId id) { this.id = id; return this; }
        public Builder usuario(Usuario usuario) { this.usuario = usuario; return this; }
        public Builder habilidad(Habilidad habilidad) { this.habilidad = habilidad; return this; }
        public Builder nivel(String nivel) { this.nivel = nivel; return this; }
        

        public HabilidadUsuario build() {
            HabilidadUsuario hu = new HabilidadUsuario(id, usuario, habilidad, nivel);
            if (hu.id == null) {
                Integer uid = usuario != null ? usuario.getIdUsuario() : null;
                Integer hid = habilidad != null ? habilidad.getIdHabilidad() : null;
                hu.setId(new HabilidadUsuarioId(uid, hid));
            }
            if (usuario != null && usuario.getHabilidades() != null) {
                usuario.getHabilidades().add(hu);
            }
            if (habilidad != null && habilidad.getUsuariosConHabilidad() != null) {
                habilidad.getUsuariosConHabilidad().add(hu);
            }
            return hu;
        }
    }
}