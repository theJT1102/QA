package com.sodimac.portalempleo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Objects;

public class CrearNotificacionDTO {

    @NotNull
    private Integer idUsuarioDestino;

    private Integer idPostulacion;

    @NotBlank
    private String asunto;

    @NotBlank
    private String mensaje;

    public CrearNotificacionDTO() {}

    public CrearNotificacionDTO(Integer idUsuarioDestino, Integer idPostulacion, String asunto, String mensaje) {
        this.idUsuarioDestino = idUsuarioDestino;
        this.idPostulacion = idPostulacion;
        this.asunto = asunto;
        this.mensaje = mensaje;
    }

    public Integer getIdUsuarioDestino() { return idUsuarioDestino; }
    public void setIdUsuarioDestino(Integer idUsuarioDestino) { this.idUsuarioDestino = idUsuarioDestino; }

    public Integer getIdPostulacion() { return idPostulacion; }
    public void setIdPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; }

    public String getAsunto() { return asunto; }
    public void setAsunto(String asunto) { this.asunto = asunto; }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CrearNotificacionDTO)) return false;
        CrearNotificacionDTO that = (CrearNotificacionDTO) o;
        return Objects.equals(idUsuarioDestino, that.idUsuarioDestino) &&
               Objects.equals(idPostulacion, that.idPostulacion) &&
               Objects.equals(asunto, that.asunto) &&
               Objects.equals(mensaje, that.mensaje);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUsuarioDestino, idPostulacion, asunto, mensaje);
    }

    @Override
    public String toString() {
        return "CrearNotificacionDTO{" +
                "idUsuarioDestino=" + idUsuarioDestino +
                ", idPostulacion=" + idPostulacion +
                ", asunto='" + asunto + '\'' +
                ", mensaje='" + mensaje + '\'' +
                '}';
    }
}