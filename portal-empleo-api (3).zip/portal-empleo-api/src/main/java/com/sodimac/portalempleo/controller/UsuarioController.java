package com.sodimac.portalempleo.controller;

import com.sodimac.portalempleo.dto.ActualizarPerfilDTO;
import com.sodimac.portalempleo.dto.ApiResponse;
import com.sodimac.portalempleo.dto.PerfilUsuarioDTO;
import com.sodimac.portalempleo.dto.UsuarioDTO;
import com.sodimac.portalempleo.security.UserDetailsImpl;
import com.sodimac.portalempleo.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/perfil")
    public ResponseEntity<ApiResponse<UsuarioDTO>> obtenerMiPerfil(Authentication authentication) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            UsuarioDTO usuario = usuarioService.obtenerPerfil(userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success(usuario, "Perfil obtenido"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error al obtener perfil: " + e.getMessage()));
        }
    }

    @PutMapping("/perfil")
    public ResponseEntity<ApiResponse<PerfilUsuarioDTO>> actualizarPerfil(
            Authentication authentication,
            @Valid @RequestBody ActualizarPerfilDTO request) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            PerfilUsuarioDTO perfil = usuarioService.actualizarPerfil(userDetails.getId(), request);
            return ResponseEntity.ok(ApiResponse.success(perfil, "Perfil actualizado"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error al actualizar: " + e.getMessage()));
        }
    }

    @PostMapping("/cv")
    public ResponseEntity<ApiResponse<String>> subirCV(
            Authentication authentication,
            @RequestParam String urlCv) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            String mensaje = usuarioService.subirCV(userDetails.getId(), urlCv);
            return ResponseEntity.ok(ApiResponse.success(urlCv, mensaje));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error al subir CV: " + e.getMessage()));
        }
    }
}