package com.sodimac.portalempleo.entity;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import jakarta.persistence.*;

@Entity
@Table(name = "Departamentos")
public class Departamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_departamento")
    private Integer idDepartamento;

    @Column(name = "nombre_departamento", nullable = false, unique = true, length = 100)
    private String nombreDepartamento;

    @OneToMany(mappedBy = "departamento")
    private Set<PuestoTrabajo> puestos = new HashSet<>();

    public Departamento() {}

    public Departamento(Integer idDepartamento, String nombreDepartamento, Set<PuestoTrabajo> puestos) {
        this.idDepartamento = idDepartamento;
        this.nombreDepartamento = nombreDepartamento;
        this.puestos = puestos != null ? puestos : new HashSet<>();
    }

    public Integer getIdDepartamento() { return idDepartamento; }
    public void setIdDepartamento(Integer idDepartamento) { this.idDepartamento = idDepartamento; }

    public String getNombreDepartamento() { return nombreDepartamento; }
    public void setNombreDepartamento(String nombreDepartamento) { this.nombreDepartamento = nombreDepartamento; }

    public Set<PuestoTrabajo> getPuestos() { return puestos; }
    public void setPuestos(Set<PuestoTrabajo> puestos) {
        this.puestos = puestos != null ? puestos : new HashSet<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Departamento)) return false;
        Departamento that = (Departamento) o;
        return Objects.equals(idDepartamento, that.idDepartamento);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idDepartamento);
    }

    @Override
    public String toString() {
        return "Departamento{" +
                "idDepartamento=" + idDepartamento +
                ", nombreDepartamento='" + nombreDepartamento + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idDepartamento;
        private String nombreDepartamento;
        private Set<PuestoTrabajo> puestos;

        public Builder idDepartamento(Integer idDepartamento) { this.idDepartamento = idDepartamento; return this; }
        public Builder nombreDepartamento(String nombreDepartamento) { this.nombreDepartamento = nombreDepartamento; return this; }
        public Builder puestos(Set<PuestoTrabajo> puestos) { this.puestos = puestos; return this; }

        public Departamento build() {
            return new Departamento(idDepartamento, nombreDepartamento, puestos);
        }
    }
}
