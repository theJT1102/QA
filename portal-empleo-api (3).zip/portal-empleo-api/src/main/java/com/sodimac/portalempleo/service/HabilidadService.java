package com.sodimac.portalempleo.service;

import com.sodimac.portalempleo.dto.AgregarHabilidadUsuarioDTO;
import com.sodimac.portalempleo.dto.HabilidadDTO;
import com.sodimac.portalempleo.dto.HabilidadUsuarioDTO;
import com.sodimac.portalempleo.entity.Habilidad;
import com.sodimac.portalempleo.entity.HabilidadUsuario;
import com.sodimac.portalempleo.entity.HabilidadUsuarioId;
import com.sodimac.portalempleo.entity.Usuario;
import com.sodimac.portalempleo.repository.HabilidadRepository;
import com.sodimac.portalempleo.repository.HabilidadUsuarioRepository;
import com.sodimac.portalempleo.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HabilidadService {

    private final HabilidadRepository habilidadRepository;
    private final HabilidadUsuarioRepository habilidadUsuarioRepository;
    private final UsuarioRepository usuarioRepository;

    public HabilidadService(HabilidadRepository habilidadRepository,
                            HabilidadUsuarioRepository habilidadUsuarioRepository,
                            UsuarioRepository usuarioRepository) {
        this.habilidadRepository = habilidadRepository;
        this.habilidadUsuarioRepository = habilidadUsuarioRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public List<HabilidadDTO> listarTodasHabilidades() {
        return habilidadRepository.findAll().stream()
                .map(h -> new HabilidadDTO(h.getIdHabilidad(), h.getNombreHabilidad()))
                .collect(Collectors.toList());
    }

    public List<HabilidadDTO> buscarHabilidades(String nombre) {
        return habilidadRepository.findByNombreHabilidadContainingIgnoreCase(nombre).stream()
                .map(h -> new HabilidadDTO(h.getIdHabilidad(), h.getNombreHabilidad()))
                .collect(Collectors.toList());
    }

    @Transactional
    public HabilidadDTO crearHabilidad(String nombreHabilidad) {
        if (habilidadRepository.findByNombreHabilidad(nombreHabilidad).isPresent()) {
            throw new RuntimeException("La habilidad ya existe");
        }

        Habilidad habilidad = new Habilidad();
        habilidad.setNombreHabilidad(nombreHabilidad);

        habilidad = habilidadRepository.save(habilidad);
        return new HabilidadDTO(habilidad.getIdHabilidad(), habilidad.getNombreHabilidad());
    }

    public List<HabilidadUsuarioDTO> obtenerHabilidadesUsuario(Integer idUsuario) {
        return habilidadUsuarioRepository.findByUsuario_IdUsuario(idUsuario).stream()
                .map(hu -> new HabilidadUsuarioDTO(
                        hu.getHabilidad().getIdHabilidad(),
                        hu.getHabilidad().getNombreHabilidad(),
                        hu.getNivel()
                ))
                .collect(Collectors.toList());
    }

    @Transactional
    public HabilidadUsuarioDTO agregarHabilidadAUsuario(Integer idUsuario, AgregarHabilidadUsuarioDTO request) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Habilidad habilidad = habilidadRepository.findById(request.getIdHabilidad())
                .orElseThrow(() -> new RuntimeException("Habilidad no encontrada"));

        HabilidadUsuarioId id = new HabilidadUsuarioId(idUsuario, request.getIdHabilidad());

        if (habilidadUsuarioRepository.findById(id).isPresent()) {
            throw new RuntimeException("El usuario ya tiene esta habilidad");
        }

        HabilidadUsuario habilidadUsuario = new HabilidadUsuario();
        habilidadUsuario.setId(id);
        habilidadUsuario.setUsuario(usuario);
        habilidadUsuario.setHabilidad(habilidad);
        habilidadUsuario.setNivel(request.getNivel());

        habilidadUsuarioRepository.save(habilidadUsuario);

        return new HabilidadUsuarioDTO(
                habilidad.getIdHabilidad(),
                habilidad.getNombreHabilidad(),
                request.getNivel()
        );
    }

    @Transactional
    public void eliminarHabilidadDeUsuario(Integer idUsuario, Integer idHabilidad) {
        HabilidadUsuarioId id = new HabilidadUsuarioId(idUsuario, idHabilidad);
        if (!habilidadUsuarioRepository.existsById(id)) {
            throw new RuntimeException("Habilidad no encontrada en el usuario");
        }
        habilidadUsuarioRepository.deleteById(id);
    }
}