package com.sodimac.portalempleo.controller;

import com.sodimac.portalempleo.dto.ApiResponse;
import com.sodimac.portalempleo.dto.CrearNotificacionDTO;
import com.sodimac.portalempleo.dto.NotificacionDTO;
import com.sodimac.portalempleo.security.UserDetailsImpl;
import com.sodimac.portalempleo.service.NotificacionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notificaciones")
public class NotificacionController {

    private final NotificacionService notificacionService;

    public NotificacionController(NotificacionService notificacionService) {
        this.notificacionService = notificacionService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<NotificacionDTO>>> obtenerMisNotificaciones(
            Authentication authentication) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            List<NotificacionDTO> notificaciones = notificacionService
                    .obtenerNotificacionesUsuario(userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success(notificaciones, "Notificaciones obtenidas"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/no-leidas")
    public ResponseEntity<ApiResponse<List<NotificacionDTO>>> obtenerNoLeidas(
            Authentication authentication) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            List<NotificacionDTO> notificaciones = notificacionService
                    .obtenerNotificacionesNoLeidas(userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success(notificaciones, "Notificaciones obtenidas"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/contar-no-leidas")
    public ResponseEntity<ApiResponse<Long>> contarNoLeidas(Authentication authentication) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            long count = notificacionService.contarNotificacionesNoLeidas(userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success(count, "Conteo obtenido"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @PutMapping("/{id}/marcar-leida")
    public ResponseEntity<ApiResponse<NotificacionDTO>> marcarComoLeida(@PathVariable Integer id) {
        try {
            NotificacionDTO notificacion = notificacionService.marcarComoLeida(id);
            return ResponseEntity.ok(ApiResponse.success(notificacion, "Notificación marcada como leída"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @PutMapping("/marcar-todas-leidas")
    public ResponseEntity<ApiResponse<Void>> marcarTodasLeidas(Authentication authentication) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            notificacionService.marcarTodasComoLeidas(userDetails.getId());
            return ResponseEntity.ok(ApiResponse.success(null, "Todas las notificaciones marcadas como leídas"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('MANAGER', 'HR')")
    public ResponseEntity<ApiResponse<NotificacionDTO>> enviarNotificacion(
            @Valid @RequestBody CrearNotificacionDTO request) {
        try {
            NotificacionDTO notificacion = notificacionService.enviarNotificacion(request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(notificacion, "Notificación enviada"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
}