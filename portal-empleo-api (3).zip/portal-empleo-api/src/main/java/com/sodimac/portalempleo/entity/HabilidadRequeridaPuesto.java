package com.sodimac.portalempleo.entity;

import java.util.Objects;
import jakarta.persistence.*;

@Entity
@Table(name = "Habilidadesrequeridaspuesto")
public class HabilidadRequeridaPuesto {

    @EmbeddedId
    private HabilidadRequeridaPuestoId id;

    @ManyToOne
    @MapsId("idPuesto")
    @JoinColumn(name = "id_puesto")
    private PuestoTrabajo puesto;

    @ManyToOne
    @MapsId("idHabilidad")
    @JoinColumn(name = "id_habilidad")
    private Habilidad habilidad;

    @Column
    private Boolean obligatorio = true;

    public HabilidadRequeridaPuesto() {}

    public HabilidadRequeridaPuesto(HabilidadRequeridaPuestoId id, PuestoTrabajo puesto, Habilidad habilidad, Boolean obligatorio) {
        this.id = id;
        this.puesto = puesto;
        this.habilidad = habilidad;
        this.obligatorio = obligatorio != null ? obligatorio : true;
    }

    public HabilidadRequeridaPuestoId getId() { return id; }
    public void setId(HabilidadRequeridaPuestoId id) { this.id = id; }

    public PuestoTrabajo getPuesto() { return puesto; }
    public void setPuesto(PuestoTrabajo puesto) {
        this.puesto = puesto;
        if (this.id == null && puesto != null && puesto.getIdPuesto() != null) {
            this.id = new HabilidadRequeridaPuestoId(puesto.getIdPuesto(), this.id != null ? this.id.getIdHabilidad() : null);
        }
    }

    public Habilidad getHabilidad() { return habilidad; }
    public void setHabilidad(Habilidad habilidad) {
        this.habilidad = habilidad;
        if (this.id == null && habilidad != null && habilidad.getIdHabilidad() != null) {
            this.id = new HabilidadRequeridaPuestoId(this.id != null ? this.id.getIdPuesto() : null, habilidad.getIdHabilidad());
        }
    }

    public Boolean getObligatorio() { return obligatorio; }
    public void setObligatorio(Boolean obligatorio) { this.obligatorio = obligatorio; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HabilidadRequeridaPuesto)) return false;
        HabilidadRequeridaPuesto that = (HabilidadRequeridaPuesto) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "HabilidadRequeridaPuesto{" +
                "id=" + (id != null ? "(" + id.getIdPuesto() + "," + id.getIdHabilidad() + ")" : null) +
                ", obligatorio=" + obligatorio +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private HabilidadRequeridaPuestoId id;
        private PuestoTrabajo puesto;
        private Habilidad habilidad;
        private Boolean obligatorio;

        public Builder id(HabilidadRequeridaPuestoId id) { this.id = id; return this; }
        public Builder puesto(PuestoTrabajo puesto) { this.puesto = puesto; return this; }
        public Builder habilidad(Habilidad habilidad) { this.habilidad = habilidad; return this; }
        public Builder obligatorio(Boolean obligatorio) { this.obligatorio = obligatorio; return this; }

        public HabilidadRequeridaPuesto build() {
            HabilidadRequeridaPuesto hrp = new HabilidadRequeridaPuesto(id, puesto, habilidad, obligatorio);
            if (hrp.id == null) {
                Integer pid = puesto != null ? puesto.getIdPuesto() : null;
                Integer hid = habilidad != null ? habilidad.getIdHabilidad() : null;
                hrp.setId(new HabilidadRequeridaPuestoId(pid, hid));
            }
            if (puesto != null && puesto.getHabilidadesRequeridas() != null) {
                puesto.getHabilidadesRequeridas().add(hrp);
            }
            return hrp;
        }
    }
}
