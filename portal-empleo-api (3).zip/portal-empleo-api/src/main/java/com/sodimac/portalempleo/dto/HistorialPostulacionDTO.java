package com.sodimac.portalempleo.dto;

import java.time.LocalDateTime;
import java.util.Objects;

public class HistorialPostulacionDTO {
    private Integer idHistorial;
    private LocalDateTime fechaCambio;
    private String nuevoEstado;
    private String comentarios;
    private UsuarioSimpleDTO gestionadoPor;

    public HistorialPostulacionDTO() {}

    public HistorialPostulacionDTO(Integer idHistorial, LocalDateTime fechaCambio, String nuevoEstado,
                                   String comentarios, UsuarioSimpleDTO gestionadoPor) {
        this.idHistorial = idHistorial;
        this.fechaCambio = fechaCambio;
        this.nuevoEstado = nuevoEstado;
        this.comentarios = comentarios;
        this.gestionadoPor = gestionadoPor;
    }

    public Integer getIdHistorial() { return idHistorial; }
    public void setIdHistorial(Integer idHistorial) { this.idHistorial = idHistorial; }

    public LocalDateTime getFechaCambio() { return fechaCambio; }
    public void setFechaCambio(LocalDateTime fechaCambio) { this.fechaCambio = fechaCambio; }

    public String getNuevoEstado() { return nuevoEstado; }
    public void setNuevoEstado(String nuevoEstado) { this.nuevoEstado = nuevoEstado; }

    public String getComentarios() { return comentarios; }
    public void setComentarios(String comentarios) { this.comentarios = comentarios; }

    public UsuarioSimpleDTO getGestionadoPor() { return gestionadoPor; }
    public void setGestionadoPor(UsuarioSimpleDTO gestionadoPor) { this.gestionadoPor = gestionadoPor; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HistorialPostulacionDTO)) return false;
        HistorialPostulacionDTO that = (HistorialPostulacionDTO) o;
        return Objects.equals(idHistorial, that.idHistorial) &&
               Objects.equals(fechaCambio, that.fechaCambio) &&
               Objects.equals(nuevoEstado, that.nuevoEstado) &&
               Objects.equals(comentarios, that.comentarios) &&
               Objects.equals(gestionadoPor, that.gestionadoPor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHistorial, fechaCambio, nuevoEstado, comentarios, gestionadoPor);
    }

    @Override
    public String toString() {
        return "HistorialPostulacionDTO{" +
                "idHistorial=" + idHistorial +
                ", fechaCambio=" + fechaCambio +
                ", nuevoEstado='" + nuevoEstado + '\'' +
                ", comentarios='" + comentarios + '\'' +
                ", gestionadoPor=" + gestionadoPor +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idHistorial;
        private LocalDateTime fechaCambio;
        private String nuevoEstado;
        private String comentarios;
        private UsuarioSimpleDTO gestionadoPor;

        public Builder idHistorial(Integer idHistorial) { this.idHistorial = idHistorial; return this; }
        public Builder fechaCambio(LocalDateTime fechaCambio) { this.fechaCambio = fechaCambio; return this; }
        public Builder nuevoEstado(String nuevoEstado) { this.nuevoEstado = nuevoEstado; return this; }
        public Builder comentarios(String comentarios) { this.comentarios = comentarios; return this; }
        public Builder gestionadoPor(UsuarioSimpleDTO gestionadoPor) { this.gestionadoPor = gestionadoPor; return this; }

        public HistorialPostulacionDTO build() {
            return new HistorialPostulacionDTO(idHistorial, fechaCambio, nuevoEstado, comentarios, gestionadoPor);
        }
    }
}