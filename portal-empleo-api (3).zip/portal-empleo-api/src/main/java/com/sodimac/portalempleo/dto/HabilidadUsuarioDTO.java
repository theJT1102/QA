package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class HabilidadUsuarioDTO {
    private Integer idHabilidad;
    private String nombreHabilidad;
    private String nivel;

    public HabilidadUsuarioDTO() {}

    public HabilidadUsuarioDTO(Integer idHabilidad, String nombreHabilidad, String nivel) {
        this.idHabilidad = idHabilidad;
        this.nombreHabilidad = nombreHabilidad;
        this.nivel = nivel;
    }

    public Integer getIdHabilidad() { return idHabilidad; }
    public void setIdHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; }

    public String getNombreHabilidad() { return nombreHabilidad; }
    public void setNombreHabilidad(String nombreHabilidad) { this.nombreHabilidad = nombreHabilidad; }

    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HabilidadUsuarioDTO)) return false;
        HabilidadUsuarioDTO that = (HabilidadUsuarioDTO) o;
        return Objects.equals(idHabilidad, that.idHabilidad) &&
               Objects.equals(nombreHabilidad, that.nombreHabilidad) &&
               Objects.equals(nivel, that.nivel);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHabilidad, nombreHabilidad, nivel);
    }

    @Override
    public String toString() {
        return "HabilidadUsuarioDTO{" +
                "idHabilidad=" + idHabilidad +
                ", nombreHabilidad='" + nombreHabilidad + '\'' +
                ", nivel='" + nivel + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idHabilidad;
        private String nombreHabilidad;
        private String nivel;

        public Builder idHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; return this; }
        public Builder nombreHabilidad(String nombreHabilidad) { this.nombreHabilidad = nombreHabilidad; return this; }
        public Builder nivel(String nivel) { this.nivel = nivel; return this; }

        public HabilidadUsuarioDTO build() {
            return new HabilidadUsuarioDTO(idHabilidad, nombreHabilidad, nivel);
        }
    }
}