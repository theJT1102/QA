package com.sodimac.portalempleo.service;

import com.sodimac.portalempleo.dto.AuthResponseDTO;
import com.sodimac.portalempleo.dto.LoginRequestDTO;
import com.sodimac.portalempleo.dto.RegisterRequestDTO;
import com.sodimac.portalempleo.entity.PerfilUsuario;
import com.sodimac.portalempleo.entity.Rol;
import com.sodimac.portalempleo.entity.Usuario;
import com.sodimac.portalempleo.repository.PerfilUsuarioRepository;
import com.sodimac.portalempleo.repository.RolRepository;
import com.sodimac.portalempleo.repository.UsuarioRepository;
import com.sodimac.portalempleo.security.JwtTokenProvider;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PerfilUsuarioRepository perfilRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;

    public AuthService(UsuarioRepository usuarioRepository,
                       PerfilUsuarioRepository perfilRepository,
                       RolRepository rolRepository,
                       PasswordEncoder passwordEncoder,
                       AuthenticationManager authenticationManager,
                       JwtTokenProvider jwtTokenProvider) {
        this.usuarioRepository = usuarioRepository;
        this.perfilRepository = perfilRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Transactional
    public AuthResponseDTO register(RegisterRequestDTO request) {
        if (usuarioRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("El email ya está registrado");
        }

        Rol rol = rolRepository.findByNombreRol(request.getRol().toLowerCase())
                .orElseThrow(() -> new RuntimeException("Rol no encontrado: " + request.getRol()));

        Usuario usuario = Usuario.builder()
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .rol(rol)
                .fechaRegistro(LocalDateTime.now())
                .build();

        usuario = usuarioRepository.save(usuario);

        PerfilUsuario perfil = PerfilUsuario.builder()
                .usuario(usuario)
                .nombreCompleto(request.getNombreCompleto())
                .telefono(request.getTelefono())
                .direccion(request.getDireccion())
                .build();

        perfilRepository.save(perfil);

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String token = jwtTokenProvider.generateToken(authentication.getName());

        return AuthResponseDTO.builder()
                .token(token)
                .tipo("Bearer")
                .idUsuario(usuario.getIdUsuario())
                .email(usuario.getEmail())
                .rol(rol.getNombreRol())
                .nombreCompleto(request.getNombreCompleto())
                .build();
    }

    @Transactional
    public AuthResponseDTO login(LoginRequestDTO request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String token = jwtTokenProvider.generateToken(authentication.getName());

        Usuario usuario = usuarioRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        usuario.setUltimoLogin(LocalDateTime.now());
        usuarioRepository.save(usuario);

        PerfilUsuario perfil = perfilRepository.findByUsuario_IdUsuario(usuario.getIdUsuario())
                .orElse(null);

        return AuthResponseDTO.builder()
                .token(token)
                .tipo("Bearer")
                .idUsuario(usuario.getIdUsuario())
                .email(usuario.getEmail())
                .rol(usuario.getRol().getNombreRol())
                .nombreCompleto(perfil != null ? perfil.getNombreCompleto() : "")
                .build();
    }
}