package com.sodimac.portalempleo.controller;

import com.sodimac.portalempleo.dto.ApiResponse;
import com.sodimac.portalempleo.dto.AprobarRechazarPuestoDTO;
import com.sodimac.portalempleo.dto.CrearPuestoDTO;
import com.sodimac.portalempleo.dto.PuestoTrabajoDTO;
import com.sodimac.portalempleo.security.UserDetailsImpl;
import com.sodimac.portalempleo.service.PuestoTrabajoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/puestos")
public class PuestoTrabajoController {

    private final PuestoTrabajoService puestoService;

    public PuestoTrabajoController(PuestoTrabajoService puestoService) {
        this.puestoService = puestoService;
    }

    // Endpoints públicos
    @GetMapping("/publicos")
        public ResponseEntity<ApiResponse<List<PuestoTrabajoDTO>>> listarPuestosPublicos() {
        try {
            List<PuestoTrabajoDTO> puestos = puestoService.listarPuestosAprobados();
            return ResponseEntity.ok(ApiResponse.success(puestos, "Puestos obtenidos"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/publicos/{id}")
    public ResponseEntity<ApiResponse<PuestoTrabajoDTO>> obtenerPuestoPublico(@PathVariable Integer id) {
        try {
            PuestoTrabajoDTO puesto = puestoService.obtenerPuestoPorId(id);
            return ResponseEntity.ok(ApiResponse.success(puesto, "Puesto obtenido"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    // Endpoints protegidos
    @PostMapping
    @PreAuthorize("hasAnyRole('MANAGER','HR')")
    public ResponseEntity<ApiResponse<PuestoTrabajoDTO>> crearPuesto(
            Authentication authentication,
            @Valid @RequestBody CrearPuestoDTO request) {
        try {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            PuestoTrabajoDTO puesto = puestoService.crearPuesto(userDetails.getId(), request);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(puesto, "Puesto creado exitosamente"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error al crear puesto: " + e.getMessage()));
        }
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('MANAGER','HR')")
    public ResponseEntity<ApiResponse<List<PuestoTrabajoDTO>>> listarPuestos(
            @RequestParam(required = false) String estado) {
        try {
            List<PuestoTrabajoDTO> puestos;
            if (estado != null) {
                puestos = puestoService.listarPuestosPorEstado(estado);
            } else {
                puestos = puestoService.listarPuestosAprobados();
            }
            return ResponseEntity.ok(ApiResponse.success(puestos, "Puestos obtenidos"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @PutMapping("/aprobar-rechazar")
    @PreAuthorize("hasRole('HR')")
    public ResponseEntity<ApiResponse<PuestoTrabajoDTO>> aprobarRechazarPuesto(
            @Valid @RequestBody AprobarRechazarPuestoDTO request) {
        try {
            PuestoTrabajoDTO puesto = puestoService.aprobarRechazarPuesto(request);
            return ResponseEntity.ok(ApiResponse.success(puesto, "Puesto actualizado"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
}