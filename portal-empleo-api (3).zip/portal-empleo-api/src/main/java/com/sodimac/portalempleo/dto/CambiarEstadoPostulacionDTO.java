package com.sodimac.portalempleo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Objects;

public class CambiarEstadoPostulacionDTO {
    @NotNull
    private Integer idPostulacion;

    @NotBlank
    private String nuevoEstado; // "submitted", "reviewing", "interview", "accepted", "rejected"

    private String comentarios;
    private Boolean enviarNotificacion = true;

    public CambiarEstadoPostulacionDTO() {}

    public CambiarEstadoPostulacionDTO(Integer idPostulacion, String nuevoEstado, String comentarios, Boolean enviarNotificacion) {
        this.idPostulacion = idPostulacion;
        this.nuevoEstado = nuevoEstado;
        this.comentarios = comentarios;
        this.enviarNotificacion = enviarNotificacion != null ? enviarNotificacion : Boolean.TRUE;
    }

    public Integer getIdPostulacion() { return idPostulacion; }
    public void setIdPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; }

    public String getNuevoEstado() { return nuevoEstado; }
    public void setNuevoEstado(String nuevoEstado) { this.nuevoEstado = nuevoEstado; }

    public String getComentarios() { return comentarios; }
    public void setComentarios(String comentarios) { this.comentarios = comentarios; }

    public Boolean getEnviarNotificacion() { return enviarNotificacion; }
    public void setEnviarNotificacion(Boolean enviarNotificacion) {
        this.enviarNotificacion = enviarNotificacion != null ? enviarNotificacion : Boolean.TRUE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CambiarEstadoPostulacionDTO)) return false;
        CambiarEstadoPostulacionDTO that = (CambiarEstadoPostulacionDTO) o;
        return Objects.equals(idPostulacion, that.idPostulacion) &&
               Objects.equals(nuevoEstado, that.nuevoEstado) &&
               Objects.equals(comentarios, that.comentarios) &&
               Objects.equals(enviarNotificacion, that.enviarNotificacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPostulacion, nuevoEstado, comentarios, enviarNotificacion);
    }

    @Override
    public String toString() {
        return "CambiarEstadoPostulacionDTO{" +
                "idPostulacion=" + idPostulacion +
                ", nuevoEstado='" + nuevoEstado + '\'' +
                ", comentarios='" + comentarios + '\'' +
                ", enviarNotificacion=" + enviarNotificacion +
                '}';
    }
}