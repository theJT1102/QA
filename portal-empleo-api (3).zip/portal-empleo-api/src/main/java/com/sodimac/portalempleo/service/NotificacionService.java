package com.sodimac.portalempleo.service;

import com.sodimac.portalempleo.dto.CrearNotificacionDTO;
import com.sodimac.portalempleo.dto.NotificacionDTO;
import com.sodimac.portalempleo.entity.Notificacion;
import com.sodimac.portalempleo.entity.Postulacion;
import com.sodimac.portalempleo.entity.Usuario;
import com.sodimac.portalempleo.repository.NotificacionRepository;
import com.sodimac.portalempleo.repository.PostulacionRepository;
import com.sodimac.portalempleo.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;
    private final UsuarioRepository usuarioRepository;
    private final PostulacionRepository postulacionRepository;

    public NotificacionService(NotificacionRepository notificacionRepository,
                               UsuarioRepository usuarioRepository,
                               PostulacionRepository postulacionRepository) {
        this.notificacionRepository = notificacionRepository;
        this.usuarioRepository = usuarioRepository;
        this.postulacionRepository = postulacionRepository;
    }

    @Transactional
    public NotificacionDTO enviarNotificacion(CrearNotificacionDTO request) {
        Usuario destinatario = usuarioRepository.findById(request.getIdUsuarioDestino())
                .orElseThrow(() -> new RuntimeException("Usuario destinatario no encontrado"));

        Postulacion postulacion = null;
        if (request.getIdPostulacion() != null) {
            postulacion = postulacionRepository.findById(request.getIdPostulacion())
                    .orElse(null);
        }

        Notificacion notificacion = new Notificacion();
        notificacion.setUsuarioDestino(destinatario);
        notificacion.setPostulacion(postulacion);
        notificacion.setAsunto(request.getAsunto());
        notificacion.setMensaje(request.getMensaje());
        notificacion.setLeida(false);

        notificacion = notificacionRepository.save(notificacion);

        return convertirANotificacionDTO(notificacion);
    }

    public List<NotificacionDTO> obtenerNotificacionesUsuario(Integer idUsuario) {
        return notificacionRepository.findByUsuarioDestino_IdUsuarioOrderByFechaEnvioDesc(idUsuario)
                .stream()
                .map(this::convertirANotificacionDTO)
                .collect(Collectors.toList());
    }

    public List<NotificacionDTO> obtenerNotificacionesNoLeidas(Integer idUsuario) {
        return notificacionRepository.findByUsuarioDestino_IdUsuarioAndLeidaOrderByFechaEnvioDesc(idUsuario, false)
                .stream()
                .map(this::convertirANotificacionDTO)
                .collect(Collectors.toList());
    }

    public long contarNotificacionesNoLeidas(Integer idUsuario) {
        return notificacionRepository.countNoLeidasByUsuario(idUsuario);
    }

    @Transactional
    public NotificacionDTO marcarComoLeida(Integer idNotificacion) {
        Notificacion notificacion = notificacionRepository.findById(idNotificacion)
                .orElseThrow(() -> new RuntimeException("Notificación no encontrada"));

        notificacion.setLeida(true);
        notificacion = notificacionRepository.save(notificacion);

        return convertirANotificacionDTO(notificacion);
    }

    @Transactional
    public void marcarTodasComoLeidas(Integer idUsuario) {
        List<Notificacion> notificaciones = notificacionRepository
                .findByUsuarioDestino_IdUsuarioAndLeidaOrderByFechaEnvioDesc(idUsuario, false);

        notificaciones.forEach(n -> n.setLeida(true));
        notificacionRepository.saveAll(notificaciones);
    }

    private NotificacionDTO convertirANotificacionDTO(Notificacion notificacion) {
        Integer idPost = notificacion.getPostulacion() != null ?
                notificacion.getPostulacion().getIdPostulacion() : null;

        return new NotificacionDTO(
                notificacion.getIdNotificacion(),
                notificacion.getFechaEnvio(),
                notificacion.getAsunto(),
                notificacion.getMensaje(),
                notificacion.getLeida(),
                idPost
        );
    }
}