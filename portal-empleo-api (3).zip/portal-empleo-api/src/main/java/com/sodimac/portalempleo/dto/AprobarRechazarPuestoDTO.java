package com.sodimac.portalempleo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Objects;

public class AprobarRechazarPuestoDTO {

    @NotNull
    private Integer idPuesto;

    @NotBlank
    private String accion; // "approve" o "reject"

    private String comentario;

    public AprobarRechazarPuestoDTO() {}

    public AprobarRechazarPuestoDTO(Integer idPuesto, String accion, String comentario) {
        this.idPuesto = idPuesto;
        this.accion = accion;
        this.comentario = comentario;
    }

    public Integer getIdPuesto() { return idPuesto; }
    public void setIdPuesto(Integer idPuesto) { this.idPuesto = idPuesto; }

    public String getAccion() { return accion; }
    public void setAccion(String accion) { this.accion = accion; }

    public String getComentario() { return comentario; }
    public void setComentario(String comentario) { this.comentario = comentario; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AprobarRechazarPuestoDTO)) return false;
        AprobarRechazarPuestoDTO that = (AprobarRechazarPuestoDTO) o;
        return Objects.equals(idPuesto, that.idPuesto) &&
               Objects.equals(accion, that.accion) &&
               Objects.equals(comentario, that.comentario);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPuesto, accion, comentario);
    }

    @Override
    public String toString() {
        return "AprobarRechazarPuestoDTO{" +
                "idPuesto=" + idPuesto +
                ", accion='" + accion + '\'' +
                ", comentario='" + comentario + '\'' +
                '}';
    }
}