package com.sodimac.portalempleo.entity;

import java.io.Serializable;
import java.util.Objects;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class HabilidadUsuarioId implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "id_usuario")
    private Integer idUsuario;

    @Column(name = "id_habilidad")
    private Integer idHabilidad;

    public HabilidadUsuarioId() {}

    public HabilidadUsuarioId(Integer idUsuario, Integer idHabilidad) {
        this.idUsuario = idUsuario;
        this.idHabilidad = idHabilidad;
    }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public Integer getIdHabilidad() { return idHabilidad; }
    public void setIdHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HabilidadUsuarioId)) return false;
        HabilidadUsuarioId that = (HabilidadUsuarioId) o;
        return Objects.equals(idUsuario, that.idUsuario) && Objects.equals(idHabilidad, that.idHabilidad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUsuario, idHabilidad);
    }

    @Override
    public String toString() {
        return "HabilidadUsuarioId{" +
                "idUsuario=" + idUsuario +
                ", idHabilidad=" + idHabilidad +
                '}';
    }
}