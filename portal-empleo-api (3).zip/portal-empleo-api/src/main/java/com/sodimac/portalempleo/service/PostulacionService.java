package com.sodimac.portalempleo.service;

import com.sodimac.portalempleo.dto.*;
import com.sodimac.portalempleo.entity.*;
import com.sodimac.portalempleo.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PostulacionService {

    private final PostulacionRepository postulacionRepository;
    private final PuestoTrabajoRepository puestoRepository;
    private final UsuarioRepository usuarioRepository;
    private final HistorialPostulacionRepository historialRepository;
    private final NotificacionService notificacionService;

    public PostulacionService(PostulacionRepository postulacionRepository,
                              PuestoTrabajoRepository puestoRepository,
                              UsuarioRepository usuarioRepository,
                              HistorialPostulacionRepository historialRepository,
                              NotificacionService notificacionService) {
        this.postulacionRepository = postulacionRepository;
        this.puestoRepository = puestoRepository;
        this.usuarioRepository = usuarioRepository;
        this.historialRepository = historialRepository;
        this.notificacionService = notificacionService;
    }

    @Transactional
    public PostulacionDTO crearPostulacion(Integer idCandidato, CrearPostulacionDTO request) {
        if (postulacionRepository.existsByCandidatoIdAndPuestoId(idCandidato, request.getIdPuesto())) {
            throw new RuntimeException("Ya has postulado a este puesto");
        }

        Usuario candidato = usuarioRepository.findById(idCandidato)
                .orElseThrow(() -> new RuntimeException("Candidato no encontrado"));

        PuestoTrabajo puesto = puestoRepository.findById(request.getIdPuesto())
                .orElseThrow(() -> new RuntimeException("Puesto no encontrado"));

        if (!puesto.getEstado().equals("approved")) {
            throw new RuntimeException("El puesto no está disponible para postulaciones");
        }

        Postulacion postulacion = new Postulacion();
        postulacion.setCandidato(candidato);
        postulacion.setPuesto(puesto);
        postulacion.setEstadoActual("submitted");
        postulacion.setCartaPresentacion(request.getCartaPresentacion());
        postulacion = postulacionRepository.save(postulacion);

        HistorialPostulacion historial = new HistorialPostulacion();
        historial.setPostulacion(postulacion);
        historial.setNuevoEstado("submitted");
        historial.setComentarios("Postulación enviada por el candidato");
        historialRepository.save(historial);

        CrearNotificacionDTO notifReq = new CrearNotificacionDTO();
        notifReq.setIdUsuarioDestino(puesto.getCreadoPor().getIdUsuario());
        notifReq.setIdPostulacion(postulacion.getIdPostulacion());
        notifReq.setAsunto("Nueva postulación recibida");
        notifReq.setMensaje("Has recibido una nueva postulación para el puesto: " + puesto.getTitulo());
        notificacionService.enviarNotificacion(notifReq);

        return convertirAPostulacionDTO(postulacion);
    }

    public List<PostulacionDTO> listarPostulacionesCandidato(Integer idCandidato) {
        return postulacionRepository.findByCandidato_IdUsuario(idCandidato).stream()
                .map(this::convertirAPostulacionDTO)
                .collect(Collectors.toList());
    }

    public List<PostulacionDTO> listarPostulacionesPorPuesto(Integer idPuesto) {
        return postulacionRepository.findByPuesto_IdPuesto(idPuesto).stream()
                .map(this::convertirAPostulacionDTO)
                .collect(Collectors.toList());
    }

    public PostulacionDTO obtenerPostulacion(Integer idPostulacion) {
        Postulacion postulacion = postulacionRepository.findById(idPostulacion)
                .orElseThrow(() -> new RuntimeException("Postulación no encontrada"));
        return convertirAPostulacionDTO(postulacion);
    }

    @Transactional
    public PostulacionDTO cambiarEstado(Integer idGestor, CambiarEstadoPostulacionDTO request) {
        Postulacion postulacion = postulacionRepository.findById(request.getIdPostulacion())
                .orElseThrow(() -> new RuntimeException("Postulación no encontrada"));

        Usuario gestor = usuarioRepository.findById(idGestor)
                .orElseThrow(() -> new RuntimeException("Gestor no encontrado"));

        postulacion.setEstadoActual(request.getNuevoEstado());
        postulacion = postulacionRepository.save(postulacion);

        HistorialPostulacion historial = new HistorialPostulacion();
        historial.setPostulacion(postulacion);
        historial.setNuevoEstado(request.getNuevoEstado());
        historial.setComentarios(request.getComentarios());
        historial.setGestionadoPor(gestor);
        historialRepository.save(historial);

        if (request.getEnviarNotificacion() == null || request.getEnviarNotificacion()) {
            String mensaje = generarMensajeNotificacion(request.getNuevoEstado(),
                    postulacion.getPuesto().getTitulo(), request.getComentarios());

            CrearNotificacionDTO notifReq = new CrearNotificacionDTO();
            notifReq.setIdUsuarioDestino(postulacion.getCandidato().getIdUsuario());
            notifReq.setIdPostulacion(postulacion.getIdPostulacion());
            notifReq.setAsunto("Actualización de tu postulación");
            notifReq.setMensaje(mensaje);
            notificacionService.enviarNotificacion(notifReq);
        }

        return convertirAPostulacionDTO(postulacion);
    }

    public List<HistorialPostulacionDTO> obtenerHistorial(Integer idPostulacion) {
        return historialRepository.findByPostulacion_IdPostulacion(idPostulacion).stream()
                .map(this::convertirAHistorialDTO)
                .collect(Collectors.toList());
    }

    private String generarMensajeNotificacion(String estado, String tituloPuesto, String comentarios) {
        StringBuilder sb = new StringBuilder();
        sb.append("Tu postulación para el puesto '").append(tituloPuesto).append("' ha sido actualizada a: ").append(estado).append(".");
        if (comentarios != null && !comentarios.isEmpty()) {
            sb.append("\n\nComentarios: ").append(comentarios);
        }
        return sb.toString();
    }

    private PostulacionDTO convertirAPostulacionDTO(Postulacion postulacion) {
        PerfilUsuario perfilCandidato = postulacion.getCandidato() != null ? postulacion.getCandidato().getPerfil() : null;

        UsuarioSimpleDTO candidatoDTO = new UsuarioSimpleDTO(
                postulacion.getCandidato().getIdUsuario(),
                postulacion.getCandidato().getEmail(),
                perfilCandidato != null ? perfilCandidato.getNombreCompleto() : ""
        );

        PuestoSimpleDTO puestoDTO = new PuestoSimpleDTO(
                postulacion.getPuesto().getIdPuesto(),
                postulacion.getPuesto().getTitulo(),
                postulacion.getPuesto().getUbicacion(),
                postulacion.getPuesto().getTipoContrato() != null ? postulacion.getPuesto().getTipoContrato().name() : null,
                postulacion.getPuesto().getEstado()
        );

        return new PostulacionDTO(
                postulacion.getIdPostulacion(),
                candidatoDTO,
                puestoDTO,
                postulacion.getFechaPostulacion(),
                postulacion.getEstadoActual(),
                postulacion.getCartaPresentacion()
        );
    }

    private HistorialPostulacionDTO convertirAHistorialDTO(HistorialPostulacion historial) {
        UsuarioSimpleDTO gestorDTO = null;
        if (historial.getGestionadoPor() != null) {
            PerfilUsuario perfil = historial.getGestionadoPor().getPerfil();
            gestorDTO = new UsuarioSimpleDTO(
                    historial.getGestionadoPor().getIdUsuario(),
                    historial.getGestionadoPor().getEmail(),
                    perfil != null ? perfil.getNombreCompleto() : ""
            );
        }

        return new HistorialPostulacionDTO(
                historial.getIdHistorial(),
                historial.getFechaCambio(),
                historial.getNuevoEstado(),
                historial.getComentarios(),
                gestorDTO
        );
    }
    @Transactional(readOnly = true)
    public List<PostulacionDTO> listarTodas() {
        try {
            // usar repositorio que devuelve entidades con joins para evitar LazyInitializationException
            List<Postulacion> entidades = postulacionRepository.findAllWithPuestoAndCandidato();
            return entidades.stream().map(this::convertirAPostulacionDTO).collect(Collectors.toList());
        } catch (Exception ex) {
            // registrar y propagar para que el controlador devuelva 500 con mensaje claro
            throw new RuntimeException("Error al listar todas las postulaciones", ex);
        }
    }

    @Transactional(readOnly = true)
    public List<PostulacionDTO> listarParaManager(Integer idGestor) {
        try {
            // ejemplo: obtener puestos a cargo del manager y luego sus postulaciones
            List<PuestoTrabajo> puestos = puestoRepository.findByCreadoPor_IdUsuario(idGestor);
            if (puestos == null || puestos.isEmpty()) {
                return List.of();
            }
            List<Integer> puestoIds = puestos.stream().map(PuestoTrabajo::getIdPuesto).collect(Collectors.toList());
            List<Postulacion> entidades = postulacionRepository.findByPuesto_IdPuestoInWithCandidato(puestoIds);
            return entidades.stream().map(this::convertirAPostulacionDTO).collect(Collectors.toList());
        } catch (Exception ex) {
            throw new RuntimeException("Error al listar postulaciones para manager", ex);
        }
    }

}