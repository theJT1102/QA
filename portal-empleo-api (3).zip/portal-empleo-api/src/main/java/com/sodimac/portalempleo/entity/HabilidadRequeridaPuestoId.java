package com.sodimac.portalempleo.entity;

import java.io.Serializable;
import java.util.Objects;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class HabilidadRequeridaPuestoId implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "id_puesto")
    private Integer idPuesto;

    @Column(name = "id_habilidad")
    private Integer idHabilidad;

    public HabilidadRequeridaPuestoId() {}

    public HabilidadRequeridaPuestoId(Integer idPuesto, Integer idHabilidad) {
        this.idPuesto = idPuesto;
        this.idHabilidad = idHabilidad;
    }

    public Integer getIdPuesto() { return idPuesto; }
    public void setIdPuesto(Integer idPuesto) { this.idPuesto = idPuesto; }

    public Integer getIdHabilidad() { return idHabilidad; }
    public void setIdHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HabilidadRequeridaPuestoId)) return false;
        HabilidadRequeridaPuestoId that = (HabilidadRequeridaPuestoId) o;
        return Objects.equals(idPuesto, that.idPuesto) && Objects.equals(idHabilidad, that.idHabilidad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPuesto, idHabilidad);
    }

    @Override
    public String toString() {
        return "HabilidadRequeridaPuestoId{" +
                "idPuesto=" + idPuesto +
                ", idHabilidad=" + idHabilidad +
                '}';
    }
}
