package com.sodimac.portalempleo.service;

import com.sodimac.portalempleo.dto.ActualizarPerfilDTO;
import com.sodimac.portalempleo.dto.PerfilUsuarioDTO;
import com.sodimac.portalempleo.dto.UsuarioDTO;
import com.sodimac.portalempleo.entity.PerfilUsuario;
import com.sodimac.portalempleo.entity.Usuario;
import com.sodimac.portalempleo.repository.PerfilUsuarioRepository;
import com.sodimac.portalempleo.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PerfilUsuarioRepository perfilRepository;

    public UsuarioService(UsuarioRepository usuarioRepository,
                          PerfilUsuarioRepository perfilRepository) {
        this.usuarioRepository = usuarioRepository;
        this.perfilRepository = perfilRepository;
    }

    public UsuarioDTO obtenerPerfil(Integer idUsuario) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        PerfilUsuario perfil = perfilRepository.findByUsuario_IdUsuario(idUsuario)
                .orElse(null);

        return convertirADTO(usuario, perfil);
    }

    @Transactional
    public PerfilUsuarioDTO actualizarPerfil(Integer idUsuario, ActualizarPerfilDTO request) {
        PerfilUsuario perfil = perfilRepository.findByUsuario_IdUsuario(idUsuario)
                .orElseThrow(() -> new RuntimeException("Perfil no encontrado"));

        if (request.getNombreCompleto() != null) {
            perfil.setNombreCompleto(request.getNombreCompleto());
        }
        if (request.getTelefono() != null) {
            perfil.setTelefono(request.getTelefono());
        }
        if (request.getDireccion() != null) {
            perfil.setDireccion(request.getDireccion());
        }

        perfil = perfilRepository.save(perfil);

        return new PerfilUsuarioDTO(
                perfil.getIdPerfil(),
                perfil.getNombreCompleto(),
                perfil.getTelefono(),
                perfil.getDireccion(),
                perfil.getUrlCvAlmacenado()
        );
    }

    @Transactional
    public String subirCV(Integer idUsuario, String urlCv) {
        PerfilUsuario perfil = perfilRepository.findByUsuario_IdUsuario(idUsuario)
                .orElseThrow(() -> new RuntimeException("Perfil no encontrado"));

        perfil.setUrlCvAlmacenado(urlCv);
        perfilRepository.save(perfil);

        return "CV subido exitosamente";
    }

    private UsuarioDTO convertirADTO(Usuario usuario, PerfilUsuario perfil) {
        PerfilUsuarioDTO perfilDTO = null;
        if (perfil != null) {
            perfilDTO = new PerfilUsuarioDTO(
                    perfil.getIdPerfil(),
                    perfil.getNombreCompleto(),
                    perfil.getTelefono(),
                    perfil.getDireccion(),
                    perfil.getUrlCvAlmacenado()
            );
        }

        return new UsuarioDTO(
                usuario.getIdUsuario(),
                usuario.getEmail(),
                usuario.getRol() != null ? usuario.getRol().getNombreRol() : null,
                usuario.getFechaRegistro() != null ? usuario.getFechaRegistro() : null,
                usuario.getUltimoLogin() != null ? usuario.getUltimoLogin() : null,
                perfilDTO
        );
    }
}