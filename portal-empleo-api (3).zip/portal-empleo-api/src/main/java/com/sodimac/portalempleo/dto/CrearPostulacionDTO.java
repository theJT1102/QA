package com.sodimac.portalempleo.dto;

import jakarta.validation.constraints.NotNull;
import java.util.Objects;

public class CrearPostulacionDTO {

    @NotNull(message = "El ID del puesto es requerido")
    private Integer idPuesto;

    private String cartaPresentacion;

    public CrearPostulacionDTO() {}

    public CrearPostulacionDTO(Integer idPuesto, String cartaPresentacion) {
        this.idPuesto = idPuesto;
        this.cartaPresentacion = cartaPresentacion;
    }

    public Integer getIdPuesto() { return idPuesto; }
    public void setIdPuesto(Integer idPuesto) { this.idPuesto = idPuesto; }

    public String getCartaPresentacion() { return cartaPresentacion; }
    public void setCartaPresentacion(String cartaPresentacion) { this.cartaPresentacion = cartaPresentacion; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CrearPostulacionDTO)) return false;
        CrearPostulacionDTO that = (CrearPostulacionDTO) o;
        return Objects.equals(idPuesto, that.idPuesto) &&
               Objects.equals(cartaPresentacion, that.cartaPresentacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPuesto, cartaPresentacion);
    }

    @Override
    public String toString() {
        return "CrearPostulacionDTO{" +
                "idPuesto=" + idPuesto +
                ", cartaPresentacion='" + cartaPresentacion + '\'' +
                '}';
    }
}