package com.sodimac.portalempleo.repository;

import com.sodimac.portalempleo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface HabilidadRepository extends JpaRepository<Habilidad, Integer> {
    Optional<Habilidad> findByNombreHabilidad(String nombre);
    List<Habilidad> findByNombreHabilidadContainingIgnoreCase(String nombre);
}
