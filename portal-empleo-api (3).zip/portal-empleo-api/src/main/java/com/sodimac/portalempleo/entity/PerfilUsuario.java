package com.sodimac.portalempleo.entity;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "Perfilesusuario")
public class PerfilUsuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_perfil")
    private Integer idPerfil;

    @OneToOne
    @JoinColumn(name = "id_usuario", nullable = false, unique = true)
    private Usuario usuario;

    @Column(name = "nombre_completo", nullable = false, length = 150)
    private String nombreCompleto;

    @Column(length = 20)
    private String telefono;

    @Column(length = 255)
    private String direccion;

    @Column(name = "url_cv_almacenado")
    private String urlCvAlmacenado;

    public PerfilUsuario() {}

    public PerfilUsuario(Integer idPerfil, Usuario usuario, String nombreCompleto, String telefono, String direccion, String urlCvAlmacenado) {
        this.idPerfil = idPerfil;
        this.usuario = usuario;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.direccion = direccion;
        this.urlCvAlmacenado = urlCvAlmacenado;
    }

    public Integer getIdPerfil() { return idPerfil; }
    public void setIdPerfil(Integer idPerfil) { this.idPerfil = idPerfil; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getUrlCvAlmacenado() { return urlCvAlmacenado; }
    public void setUrlCvAlmacenado(String urlCvAlmacenado) { this.urlCvAlmacenado = urlCvAlmacenado; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PerfilUsuario)) return false;
        PerfilUsuario that = (PerfilUsuario) o;
        return Objects.equals(idPerfil, that.idPerfil);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPerfil);
    }

    @Override
    public String toString() {
        return "PerfilUsuario{" +
                "idPerfil=" + idPerfil +
                ", nombreCompleto='" + nombreCompleto + '\'' +
                ", telefono='" + telefono + '\'' +
                ", direccion='" + direccion + '\'' +
                ", urlCvAlmacenado='" + urlCvAlmacenado + '\'' +
                '}';
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Integer idPerfil;
        private Usuario usuario;
        private String nombreCompleto;
        private String telefono;
        private String direccion;
        private String urlCvAlmacenado;

        public Builder idPerfil(Integer idPerfil) { this.idPerfil = idPerfil; return this; }
        public Builder usuario(Usuario usuario) { this.usuario = usuario; return this; }
        public Builder nombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; return this; }
        public Builder telefono(String telefono) { this.telefono = telefono; return this; }
        public Builder direccion(String direccion) { this.direccion = direccion; return this; }
        public Builder urlCvAlmacenado(String urlCvAlmacenado) { this.urlCvAlmacenado = urlCvAlmacenado; return this; }

        public PerfilUsuario build() {
            return new PerfilUsuario(idPerfil, usuario, nombreCompleto, telefono, direccion, urlCvAlmacenado);
        }
    }
}
