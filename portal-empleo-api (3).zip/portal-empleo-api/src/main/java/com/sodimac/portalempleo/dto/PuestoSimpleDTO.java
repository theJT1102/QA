package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class PuestoSimpleDTO {
    private Integer idPuesto;
    private String titulo;
    private String ubicacion;
    private String tipoContrato;
    private String estado;

    public PuestoSimpleDTO() {}

    public PuestoSimpleDTO(Integer idPuesto, String titulo, String ubicacion, String tipoContrato, String estado) {
        this.idPuesto = idPuesto;
        this.titulo = titulo;
        this.ubicacion = ubicacion;
        this.tipoContrato = tipoContrato;
        this.estado = estado;
    }

    public Integer getIdPuesto() { return idPuesto; }
    public void setIdPuesto(Integer idPuesto) { this.idPuesto = idPuesto; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public String getTipoContrato() { return tipoContrato; }
    public void setTipoContrato(String tipoContrato) { this.tipoContrato = tipoContrato; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PuestoSimpleDTO)) return false;
        PuestoSimpleDTO that = (PuestoSimpleDTO) o;
        return Objects.equals(idPuesto, that.idPuesto) &&
               Objects.equals(titulo, that.titulo) &&
               Objects.equals(ubicacion, that.ubicacion) &&
               Objects.equals(tipoContrato, that.tipoContrato) &&
               Objects.equals(estado, that.estado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPuesto, titulo, ubicacion, tipoContrato, estado);
    }

    @Override
    public String toString() {
        return "PuestoSimpleDTO{" +
                "idPuesto=" + idPuesto +
                ", titulo='" + titulo + '\'' +
                ", ubicacion='" + ubicacion + '\'' +
                ", tipoContrato='" + tipoContrato + '\'' +
                ", estado='" + estado + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idPuesto;
        private String titulo;
        private String ubicacion;
        private String tipoContrato;
        private String estado;

        public Builder idPuesto(Integer idPuesto) { this.idPuesto = idPuesto; return this; }
        public Builder titulo(String titulo) { this.titulo = titulo; return this; }
        public Builder ubicacion(String ubicacion) { this.ubicacion = ubicacion; return this; }
        public Builder tipoContrato(String tipoContrato) { this.tipoContrato = tipoContrato; return this; }
        public Builder estado(String estado) { this.estado = estado; return this; }

        public PuestoSimpleDTO build() {
            return new PuestoSimpleDTO(idPuesto, titulo, ubicacion, tipoContrato, estado);
        }
    }
}