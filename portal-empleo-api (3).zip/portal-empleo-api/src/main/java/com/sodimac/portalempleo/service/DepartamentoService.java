package com.sodimac.portalempleo.service;

import com.sodimac.portalempleo.dto.DepartamentoDTO;
import com.sodimac.portalempleo.entity.Departamento;
import com.sodimac.portalempleo.repository.DepartamentoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DepartamentoService {

    private final DepartamentoRepository departamentoRepository;

    public DepartamentoService(DepartamentoRepository departamentoRepository) {
        this.departamentoRepository = departamentoRepository;
    }

    @Transactional(readOnly = true)
    public List<DepartamentoDTO> listarDepartamentos() {
        return departamentoRepository.findAll().stream()
                .map(d -> new DepartamentoDTO(d.getIdDepartamento(), d.getNombreDepartamento()))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public DepartamentoDTO obtenerDepartamento(Integer idDepartamento) {
        Departamento departamento = departamentoRepository.findById(idDepartamento)
                .orElseThrow(() -> new RuntimeException("Departamento no encontrado"));

        return new DepartamentoDTO(departamento.getIdDepartamento(), departamento.getNombreDepartamento());
    }
}