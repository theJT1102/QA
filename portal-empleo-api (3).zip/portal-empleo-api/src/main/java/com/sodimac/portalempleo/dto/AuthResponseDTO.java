package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class AuthResponseDTO {
    private String token;
    private String tipo = "Bearer";
    private Integer idUsuario;
    private String email;
    private String rol;
    private String nombreCompleto;

    public AuthResponseDTO() {}

    public AuthResponseDTO(String token, String tipo, Integer idUsuario, String email, String rol, String nombreCompleto) {
        this.token = token;
        this.tipo = tipo != null ? tipo : "Bearer";
        this.idUsuario = idUsuario;
        this.email = email;
        this.rol = rol;
        this.nombreCompleto = nombreCompleto;
    }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo != null ? tipo : "Bearer"; }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuthResponseDTO)) return false;
        AuthResponseDTO that = (AuthResponseDTO) o;
        return Objects.equals(token, that.token) &&
               Objects.equals(tipo, that.tipo) &&
               Objects.equals(idUsuario, that.idUsuario) &&
               Objects.equals(email, that.email) &&
               Objects.equals(rol, that.rol) &&
               Objects.equals(nombreCompleto, that.nombreCompleto);
    }

    @Override
    public int hashCode() {
        return Objects.hash(token, tipo, idUsuario, email, rol, nombreCompleto);
    }

    @Override
    public String toString() {
        return "AuthResponseDTO{" +
                "token='" + token + '\'' +
                ", tipo='" + tipo + '\'' +
                ", idUsuario=" + idUsuario +
                ", email='" + email + '\'' +
                ", rol='" + rol + '\'' +
                ", nombreCompleto='" + nombreCompleto + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String token;
        private String tipo = "Bearer";
        private Integer idUsuario;
        private String email;
        private String rol;
        private String nombreCompleto;

        public Builder token(String token) { this.token = token; return this; }
        public Builder tipo(String tipo) { this.tipo = tipo != null ? tipo : "Bearer"; return this; }
        public Builder idUsuario(Integer idUsuario) { this.idUsuario = idUsuario; return this; }
        public Builder email(String email) { this.email = email; return this; }
        public Builder rol(String rol) { this.rol = rol; return this; }
        public Builder nombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; return this; }

        public AuthResponseDTO build() {
            return new AuthResponseDTO(token, tipo, idUsuario, email, rol, nombreCompleto);
        }
    }
}