package com.sodimac.portalempleo.controller;

import com.sodimac.portalempleo.dto.ApiResponse;
import com.sodimac.portalempleo.dto.DepartamentoDTO;
import com.sodimac.portalempleo.service.DepartamentoService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departamentos")
public class DepartamentoController {

    private final DepartamentoService departamentoService;

    public DepartamentoController(DepartamentoService departamentoService) {
        this.departamentoService = departamentoService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<DepartamentoDTO>>> listarDepartamentos() {
        try {
            List<DepartamentoDTO> departamentos = departamentoService.listarDepartamentos();
            return ResponseEntity.ok(ApiResponse.success(departamentos, "Departamentos obtenidos"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<DepartamentoDTO>> obtenerDepartamento(@PathVariable Integer id) {
        try {
            DepartamentoDTO departamento = departamentoService.obtenerDepartamento(id);
            return ResponseEntity.ok(ApiResponse.success(departamento, "Departamento obtenido"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Error: " + e.getMessage()));
        }
    }
}
