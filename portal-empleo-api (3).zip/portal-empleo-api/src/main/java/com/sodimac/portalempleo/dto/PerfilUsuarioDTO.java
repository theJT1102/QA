package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class PerfilUsuarioDTO {
    private Integer idPerfil;
    private String nombreCompleto;
    private String telefono;
    private String direccion;
    private String urlCvAlmacenado;

    public PerfilUsuarioDTO() {}

    public PerfilUsuarioDTO(Integer idPerfil, String nombreCompleto, String telefono, String direccion, String urlCvAlmacenado) {
        this.idPerfil = idPerfil;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.direccion = direccion;
        this.urlCvAlmacenado = urlCvAlmacenado;
    }

    public Integer getIdPerfil() { return idPerfil; }
    public void setIdPerfil(Integer idPerfil) { this.idPerfil = idPerfil; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getUrlCvAlmacenado() { return urlCvAlmacenado; }
    public void setUrlCvAlmacenado(String urlCvAlmacenado) { this.urlCvAlmacenado = urlCvAlmacenado; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PerfilUsuarioDTO)) return false;
        PerfilUsuarioDTO that = (PerfilUsuarioDTO) o;
        return Objects.equals(idPerfil, that.idPerfil) &&
               Objects.equals(nombreCompleto, that.nombreCompleto) &&
               Objects.equals(telefono, that.telefono) &&
               Objects.equals(direccion, that.direccion) &&
               Objects.equals(urlCvAlmacenado, that.urlCvAlmacenado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPerfil, nombreCompleto, telefono, direccion, urlCvAlmacenado);
    }

    @Override
    public String toString() {
        return "PerfilUsuarioDTO{" +
                "idPerfil=" + idPerfil +
                ", nombreCompleto='" + nombreCompleto + '\'' +
                ", telefono='" + telefono + '\'' +
                ", direccion='" + direccion + '\'' +
                ", urlCvAlmacenado='" + urlCvAlmacenado + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idPerfil;
        private String nombreCompleto;
        private String telefono;
        private String direccion;
        private String urlCvAlmacenado;

        public Builder idPerfil(Integer idPerfil) { this.idPerfil = idPerfil; return this; }
        public Builder nombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; return this; }
        public Builder telefono(String telefono) { this.telefono = telefono; return this; }
        public Builder direccion(String direccion) { this.direccion = direccion; return this; }
        public Builder urlCvAlmacenado(String urlCvAlmacenado) { this.urlCvAlmacenado = urlCvAlmacenado; return this; }

        public PerfilUsuarioDTO build() {
            return new PerfilUsuarioDTO(idPerfil, nombreCompleto, telefono, direccion, urlCvAlmacenado);
        }
    }
}