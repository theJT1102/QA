package com.sodimac.portalempleo.entity;

import java.time.LocalDateTime;
import java.util.Objects;
import jakarta.persistence.*;

@Entity
@Table(name = "Historialpostulacion")
public class HistorialPostulacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_historial")
    private Integer idHistorial;

    @ManyToOne
    @JoinColumn(name = "id_postulacion", nullable = false)
    private Postulacion postulacion;

    @Column(name = "fecha_cambio")
    private LocalDateTime fechaCambio;

    @Column(name = "nuevo_estado", nullable = false, length = 50)
    private String nuevoEstado;

    @Column(columnDefinition = "TEXT")
    private String comentarios;

    @ManyToOne
    @JoinColumn(name = "gestionado_por_id")
    private Usuario gestionadoPor;

    public HistorialPostulacion() {}

    public HistorialPostulacion(Integer idHistorial, Postulacion postulacion, LocalDateTime fechaCambio,
                               String nuevoEstado, String comentarios, Usuario gestionadoPor) {
        this.idHistorial = idHistorial;
        this.postulacion = postulacion;
        this.fechaCambio = fechaCambio;
        this.nuevoEstado = nuevoEstado;
        this.comentarios = comentarios;
        this.gestionadoPor = gestionadoPor;
    }

    public Integer getIdHistorial() { return idHistorial; }
    public void setIdHistorial(Integer idHistorial) { this.idHistorial = idHistorial; }

    public Postulacion getPostulacion() { return postulacion; }
    public void setPostulacion(Postulacion postulacion) { this.postulacion = postulacion; }

    public LocalDateTime getFechaCambio() { return fechaCambio; }
    public void setFechaCambio(LocalDateTime fechaCambio) { this.fechaCambio = fechaCambio; }

    public String getNuevoEstado() { return nuevoEstado; }
    public void setNuevoEstado(String nuevoEstado) { this.nuevoEstado = nuevoEstado; }

    public String getComentarios() { return comentarios; }
    public void setComentarios(String comentarios) { this.comentarios = comentarios; }

    public Usuario getGestionadoPor() { return gestionadoPor; }
    public void setGestionadoPor(Usuario gestionadoPor) { this.gestionadoPor = gestionadoPor; }

    @PrePersist
    protected void onCreate() {
        if (fechaCambio == null) {
            fechaCambio = LocalDateTime.now();
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HistorialPostulacion)) return false;
        HistorialPostulacion that = (HistorialPostulacion) o;
        return Objects.equals(idHistorial, that.idHistorial);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHistorial);
    }

    @Override
    public String toString() {
        return "HistorialPostulacion{" +
                "idHistorial=" + idHistorial +
                ", postulacion=" + (postulacion != null ? postulacion.getIdPostulacion() : null) +
                ", fechaCambio=" + fechaCambio +
                ", nuevoEstado='" + nuevoEstado + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idHistorial;
        private Postulacion postulacion;
        private LocalDateTime fechaCambio;
        private String nuevoEstado;
        private String comentarios;
        private Usuario gestionadoPor;

        public Builder idHistorial(Integer idHistorial) { this.idHistorial = idHistorial; return this; }
        public Builder postulacion(Postulacion postulacion) { this.postulacion = postulacion; return this; }
        public Builder fechaCambio(LocalDateTime fechaCambio) { this.fechaCambio = fechaCambio; return this; }
        public Builder nuevoEstado(String nuevoEstado) { this.nuevoEstado = nuevoEstado; return this; }
        public Builder comentarios(String comentarios) { this.comentarios = comentarios; return this; }
        public Builder gestionadoPor(Usuario gestionadoPor) { this.gestionadoPor = gestionadoPor; return this; }

        public HistorialPostulacion build() {
            HistorialPostulacion h = new HistorialPostulacion(idHistorial, postulacion, fechaCambio, nuevoEstado, comentarios, gestionadoPor);
            if (h.fechaCambio == null) {
                h.fechaCambio = LocalDateTime.now();
            }
            if (postulacion != null && postulacion.getHistorial() != null) {
                postulacion.getHistorial().add(h);
            }
            return h;
        }
    }
}