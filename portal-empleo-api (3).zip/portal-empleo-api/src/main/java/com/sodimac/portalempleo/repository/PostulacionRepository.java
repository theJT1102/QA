package com.sodimac.portalempleo.repository;

import com.sodimac.portalempleo.entity.Postulacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PostulacionRepository extends JpaRepository<Postulacion, Integer> {

    // Consulta para obtener todas las postulaciones con puesto y candidato (y perfil del candidato)
    @Query("SELECT p FROM Postulacion p " +
           "JOIN FETCH p.puesto pu " +
           "JOIN FETCH p.candidato c " +
           "LEFT JOIN FETCH c.perfil")
    List<Postulacion> findAllWithPuestoAndCandidato();

    // Obtener postulaciones por lista de ids de puesto, trayendo candidato y su perfil
    @Query("SELECT p FROM Postulacion p " +
           "JOIN FETCH p.candidato c " +
           "LEFT JOIN FETCH c.perfil " +
           "WHERE p.puesto.idPuesto IN :ids")
    List<Postulacion> findByPuesto_IdPuestoInWithCandidato(@Param("ids") List<Integer> ids);

    // Obtener postulaciones de un candidato (sin fetch adicional; si necesitas más relaciones, crea variante con JOIN FETCH)
    List<Postulacion> findByCandidato_IdUsuario(Integer idCandidato);

    // Obtener postulaciones por puesto simple (sin fetch)
    List<Postulacion> findByPuesto_IdPuesto(Integer idPuesto);

    // Buscar by id incluyendo puesto y candidato (útil para detalles sin Lazy problemas)
    @Query("SELECT p FROM Postulacion p " +
           "JOIN FETCH p.puesto pu " +
           "JOIN FETCH p.candidato c " +
           "LEFT JOIN FETCH c.perfil " +
           "WHERE p.idPostulacion = :id")
    Optional<Postulacion> findByIdWithPuestoAndCandidato(@Param("id") Integer id);
    
    @Query("SELECT CASE WHEN COUNT(p) > 0 THEN true ELSE false END FROM Postulacion p WHERE p.candidato.idUsuario = :idUsuario AND p.puesto.idPuesto = :idPuesto")
    boolean existsByCandidatoIdAndPuestoId(@Param("idUsuario") Integer idUsuario, @Param("idPuesto") Integer idPuesto);

}