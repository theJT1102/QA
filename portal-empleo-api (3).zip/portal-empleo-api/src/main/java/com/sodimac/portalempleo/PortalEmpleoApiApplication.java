package com.sodimac.portalempleo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortalEmpleoApiApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(PortalEmpleoApiApplication.class, args);
        System.out.println("===========================================");
        System.out.println("Portal de Empleo SODIMAC - Iniciado");
        System.out.println("Servidor corriendo en: http://localhost:8080/api");
        System.out.println("===========================================");
    }
}