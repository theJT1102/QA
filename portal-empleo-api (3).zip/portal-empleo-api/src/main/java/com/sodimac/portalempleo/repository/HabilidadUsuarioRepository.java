package com.sodimac.portalempleo.repository;

import com.sodimac.portalempleo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public interface HabilidadUsuarioRepository extends JpaRepository<HabilidadUsuario, HabilidadUsuarioId> {
    List<HabilidadUsuario> findByUsuario_IdUsuario(Integer idUsuario);
}
