package com.sodimac.portalempleo.entity;

import java.time.LocalDateTime;
import java.util.Objects;
import jakarta.persistence.*;

@Entity
@Table(name = "Notificaciones")
public class Notificacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_notificacion")
    private Integer idNotificacion;

    @ManyToOne
    @JoinColumn(name = "id_usuario_destino", nullable = false)
    private Usuario usuarioDestino;

    @ManyToOne
    @JoinColumn(name = "id_postulacion")
    private Postulacion postulacion;

    @Column(name = "fecha_envio")
    private LocalDateTime fechaEnvio;

    @Column(length = 150)
    private String asunto;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String mensaje;

    @Column
    private Boolean leida = false;

    public Notificacion() {}

    public Notificacion(Integer idNotificacion, Usuario usuarioDestino, Postulacion postulacion,
                        LocalDateTime fechaEnvio, String asunto, String mensaje, Boolean leida) {
        this.idNotificacion = idNotificacion;
        this.usuarioDestino = usuarioDestino;
        this.postulacion = postulacion;
        this.fechaEnvio = fechaEnvio;
        this.asunto = asunto;
        this.mensaje = mensaje;
        this.leida = leida != null ? leida : false;
    }

    public Integer getIdNotificacion() { return idNotificacion; }
    public void setIdNotificacion(Integer idNotificacion) { this.idNotificacion = idNotificacion; }

    public Usuario getUsuarioDestino() { return usuarioDestino; }
    public void setUsuarioDestino(Usuario usuarioDestino) { this.usuarioDestino = usuarioDestino; }

    public Postulacion getPostulacion() { return postulacion; }
    public void setPostulacion(Postulacion postulacion) { this.postulacion = postulacion; }

    public LocalDateTime getFechaEnvio() { return fechaEnvio; }
    public void setFechaEnvio(LocalDateTime fechaEnvio) { this.fechaEnvio = fechaEnvio; }

    public String getAsunto() { return asunto; }
    public void setAsunto(String asunto) { this.asunto = asunto; }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }

    public Boolean getLeida() { return leida; }
    public void setLeida(Boolean leida) { this.leida = leida; }

    @PrePersist
    protected void onCreate() {
        if (fechaEnvio == null) {
            fechaEnvio = LocalDateTime.now();
        }
        if (leida == null) {
            leida = false;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Notificacion)) return false;
        Notificacion that = (Notificacion) o;
        return Objects.equals(idNotificacion, that.idNotificacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idNotificacion);
    }

    @Override
    public String toString() {
        return "Notificacion{" +
                "idNotificacion=" + idNotificacion +
                ", usuarioDestino=" + (usuarioDestino != null ? usuarioDestino.getIdUsuario() : null) +
                ", fechaEnvio=" + fechaEnvio +
                ", asunto='" + asunto + '\'' +
                ", leida=" + leida +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idNotificacion;
        private Usuario usuarioDestino;
        private Postulacion postulacion;
        private LocalDateTime fechaEnvio;
        private String asunto;
        private String mensaje;
        private Boolean leida;

        public Builder idNotificacion(Integer idNotificacion) { this.idNotificacion = idNotificacion; return this; }
        public Builder usuarioDestino(Usuario usuarioDestino) { this.usuarioDestino = usuarioDestino; return this; }
        public Builder postulacion(Postulacion postulacion) { this.postulacion = postulacion; return this; }
        public Builder fechaEnvio(LocalDateTime fechaEnvio) { this.fechaEnvio = fechaEnvio; return this; }
        public Builder asunto(String asunto) { this.asunto = asunto; return this; }
        public Builder mensaje(String mensaje) { this.mensaje = mensaje; return this; }
        public Builder leida(Boolean leida) { this.leida = leida; return this; }

        public Notificacion build() {
            return new Notificacion(idNotificacion, usuarioDestino, postulacion, fechaEnvio, asunto, mensaje, leida);
        }
    }
}