package com.sodimac.portalempleo.repository;

import com.sodimac.portalempleo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public interface PuestoTrabajoRepository extends JpaRepository<PuestoTrabajo, Integer> {
    List<PuestoTrabajo> findByEstado(String estado);
    List<PuestoTrabajo> findByDepartamento_IdDepartamento(Integer idDepartamento);
    List<PuestoTrabajo> findByCreadoPor_IdUsuario(Integer idUsuario);
    
    @Query("SELECT p FROM PuestoTrabajo p WHERE p.estado = 'approved' ORDER BY p.fechaCreacion DESC")
    List<PuestoTrabajo> findPuestosAprobados();
}