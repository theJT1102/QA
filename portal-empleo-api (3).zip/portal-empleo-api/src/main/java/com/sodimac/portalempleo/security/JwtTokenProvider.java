package com.sodimac.portalempleo.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtTokenProvider {

    @Value("${spring.security.jwt.secret:${jwt.secret:}}")
    private String jwtSecretBase64;

    @Value("${spring.security.jwt.expiration-ms:${jwt.expiration:3600000}}")
    private long jwtExpirationMs;

    private SecretKey signingKey;

    @PostConstruct
    public void init() {
        if (jwtSecretBase64 == null || jwtSecretBase64.trim().isEmpty()) {
            throw new IllegalStateException("Missing property 'spring.security.jwt.secret' or 'jwt.secret' (must be Base64-encoded 64 bytes)");
        }
        try {
            byte[] keyBytes = Decoders.BASE64.decode(jwtSecretBase64.trim());
            if (keyBytes.length < 64) {
                throw new IllegalStateException("JWT secret too short: " + (keyBytes.length * 8) + " bits; require >= 512 bits.");
            }
            this.signingKey = Keys.hmacShaKeyFor(keyBytes);
        } catch (IllegalArgumentException ex) {
            throw new IllegalStateException("Invalid Base64 value for JWT secret: " + ex.getMessage(), ex);
        }
    }

    private SecretKey getSigningKey() {
        return signingKey;
    }

    public String generateToken(String username) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(getSigningKey(), SignatureAlgorithm.HS512)
                .compact();
    }

    public String generateToken(org.springframework.security.core.Authentication authentication) {
        return generateToken(authentication.getName());
    }

    public String getUsernameFromToken(String token) {
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
        return claims.getSubject();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token);
            return true;
        } catch (io.jsonwebtoken.JwtException | IllegalArgumentException ex) {
            return false;
        }
    }
}
