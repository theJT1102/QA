package com.sodimac.portalempleo.entity;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import jakarta.persistence.*;

@Entity
@Table(name = "Usuarios")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Integer idUsuario;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_rol", nullable = false)
    private Rol rol;

    @Column(name = "fecha_registro")
    private LocalDateTime fechaRegistro;

    @Column(name = "ultimo_login")
    private LocalDateTime ultimoLogin;

    @OneToOne(mappedBy = "usuario", cascade = CascadeType.ALL)
    private PerfilUsuario perfil;

    @OneToMany(mappedBy = "candidato")
    private Set<Postulacion> postulaciones = new HashSet<>();

    @OneToMany(mappedBy = "usuario")
    private Set<HabilidadUsuario> habilidades = new HashSet<>();

    public Usuario() {}

    public Usuario(Integer idUsuario, String email, String passwordHash, Rol rol, LocalDateTime fechaRegistro,
                   LocalDateTime ultimoLogin, PerfilUsuario perfil, Set<Postulacion> postulaciones,
                   Set<HabilidadUsuario> habilidades) {
        this.idUsuario = idUsuario;
        this.email = email;
        this.passwordHash = passwordHash;
        this.rol = rol;
        this.fechaRegistro = fechaRegistro;
        this.ultimoLogin = ultimoLogin;
        this.perfil = perfil;
        this.postulaciones = postulaciones != null ? postulaciones : new HashSet<>();
        this.habilidades = habilidades != null ? habilidades : new HashSet<>();
    }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public Rol getRol() { return rol; }
    public void setRol(Rol rol) { this.rol = rol; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public LocalDateTime getUltimoLogin() { return ultimoLogin; }
    public void setUltimoLogin(LocalDateTime ultimoLogin) { this.ultimoLogin = ultimoLogin; }

    public PerfilUsuario getPerfil() { return perfil; }
    public void setPerfil(PerfilUsuario perfil) {
        this.perfil = perfil;
        if (perfil != null && perfil.getUsuario() != this) {
            perfil.setUsuario(this);
        }
    }

    public Set<Postulacion> getPostulaciones() { return postulaciones; }
    public void setPostulaciones(Set<Postulacion> postulaciones) {
        this.postulaciones = postulaciones != null ? postulaciones : new HashSet<>();
    }

    public Set<HabilidadUsuario> getHabilidades() { return habilidades; }
    public void setHabilidades(Set<HabilidadUsuario> habilidades) {
        this.habilidades = habilidades != null ? habilidades : new HashSet<>();
    }

    @PrePersist
    protected void onCreate() {
        if (fechaRegistro == null) {
            fechaRegistro = LocalDateTime.now();
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario)) return false;
        Usuario usuario = (Usuario) o;
        return Objects.equals(idUsuario, usuario.idUsuario);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUsuario);
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "idUsuario=" + idUsuario +
                ", email='" + email + '\'' +
                ", rol=" + (rol != null ? rol.getNombreRol() : null) +
                ", fechaRegistro=" + fechaRegistro +
                ", ultimoLogin=" + ultimoLogin +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idUsuario;
        private String email;
        private String passwordHash;
        private Rol rol;
        private LocalDateTime fechaRegistro;
        private LocalDateTime ultimoLogin;
        private PerfilUsuario perfil;
        private Set<Postulacion> postulaciones;
        private Set<HabilidadUsuario> habilidades;

        public Builder idUsuario(Integer idUsuario) { this.idUsuario = idUsuario; return this; }
        public Builder email(String email) { this.email = email; return this; }
        public Builder passwordHash(String passwordHash) { this.passwordHash = passwordHash; return this; }
        public Builder rol(Rol rol) { this.rol = rol; return this; }
        public Builder fechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; return this; }
        public Builder ultimoLogin(LocalDateTime ultimoLogin) { this.ultimoLogin = ultimoLogin; return this; }
        public Builder perfil(PerfilUsuario perfil) { this.perfil = perfil; return this; }
        public Builder postulaciones(Set<Postulacion> postulaciones) { this.postulaciones = postulaciones; return this; }
        public Builder habilidades(Set<HabilidadUsuario> habilidades) { this.habilidades = habilidades; return this; }

        public Usuario build() {
            Usuario u = new Usuario(idUsuario, email, passwordHash, rol, fechaRegistro, ultimoLogin, perfil, postulaciones, habilidades);
            if (perfil != null && perfil.getUsuario() != u) {
                perfil.setUsuario(u);
            }
            return u;
        }
    }
}