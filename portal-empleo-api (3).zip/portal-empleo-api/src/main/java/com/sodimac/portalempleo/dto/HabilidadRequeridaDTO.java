package com.sodimac.portalempleo.dto;

import java.util.Objects;

public class HabilidadRequeridaDTO {
    private Integer idHabilidad;
    private String nombreHabilidad;
    private Boolean obligatorio = true;

    public HabilidadRequeridaDTO() {}

    public HabilidadRequeridaDTO(Integer idHabilidad, String nombreHabilidad, Boolean obligatorio) {
        this.idHabilidad = idHabilidad;
        this.nombreHabilidad = nombreHabilidad;
        this.obligatorio = obligatorio != null ? obligatorio : Boolean.TRUE;
    }

    public Integer getIdHabilidad() { return idHabilidad; }
    public void setIdHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; }

    public String getNombreHabilidad() { return nombreHabilidad; }
    public void setNombreHabilidad(String nombreHabilidad) { this.nombreHabilidad = nombreHabilidad; }

    public Boolean getObligatorio() { return obligatorio; }
    public void setObligatorio(Boolean obligatorio) { this.obligatorio = obligatorio != null ? obligatorio : Boolean.TRUE; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HabilidadRequeridaDTO)) return false;
        HabilidadRequeridaDTO that = (HabilidadRequeridaDTO) o;
        return Objects.equals(idHabilidad, that.idHabilidad) &&
               Objects.equals(nombreHabilidad, that.nombreHabilidad) &&
               Objects.equals(obligatorio, that.obligatorio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHabilidad, nombreHabilidad, obligatorio);
    }

    @Override
    public String toString() {
        return "HabilidadRequeridaDTO{" +
                "idHabilidad=" + idHabilidad +
                ", nombreHabilidad='" + nombreHabilidad + '\'' +
                ", obligatorio=" + obligatorio +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idHabilidad;
        private String nombreHabilidad;
        private Boolean obligatorio = true;

        public Builder idHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; return this; }
        public Builder nombreHabilidad(String nombreHabilidad) { this.nombreHabilidad = nombreHabilidad; return this; }
        public Builder obligatorio(Boolean obligatorio) { this.obligatorio = obligatorio != null ? obligatorio : Boolean.TRUE; return this; }

        public HabilidadRequeridaDTO build() {
            return new HabilidadRequeridaDTO(idHabilidad, nombreHabilidad, obligatorio);
        }
    }
}