package com.sodimac.portalempleo.dto;

import java.time.LocalDateTime;
import java.util.Objects;

public class NotificacionDTO {
    private Integer idNotificacion;
    private LocalDateTime fechaEnvio;
    private String asunto;
    private String mensaje;
    private Boolean leida;
    private Integer idPostulacion;

    public NotificacionDTO() {}

    public NotificacionDTO(Integer idNotificacion, LocalDateTime fechaEnvio, String asunto,
                           String mensaje, Boolean leida, Integer idPostulacion) {
        this.idNotificacion = idNotificacion;
        this.fechaEnvio = fechaEnvio;
        this.asunto = asunto;
        this.mensaje = mensaje;
        this.leida = leida;
        this.idPostulacion = idPostulacion;
    }

    public Integer getIdNotificacion() { return idNotificacion; }
    public void setIdNotificacion(Integer idNotificacion) { this.idNotificacion = idNotificacion; }

    public LocalDateTime getFechaEnvio() { return fechaEnvio; }
    public void setFechaEnvio(LocalDateTime fechaEnvio) { this.fechaEnvio = fechaEnvio; }

    public String getAsunto() { return asunto; }
    public void setAsunto(String asunto) { this.asunto = asunto; }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }

    public Boolean getLeida() { return leida; }
    public void setLeida(Boolean leida) { this.leida = leida; }

    public Integer getIdPostulacion() { return idPostulacion; }
    public void setIdPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NotificacionDTO)) return false;
        NotificacionDTO that = (NotificacionDTO) o;
        return Objects.equals(idNotificacion, that.idNotificacion) &&
               Objects.equals(fechaEnvio, that.fechaEnvio) &&
               Objects.equals(asunto, that.asunto) &&
               Objects.equals(mensaje, that.mensaje) &&
               Objects.equals(leida, that.leida) &&
               Objects.equals(idPostulacion, that.idPostulacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idNotificacion, fechaEnvio, asunto, mensaje, leida, idPostulacion);
    }

    @Override
    public String toString() {
        return "NotificacionDTO{" +
                "idNotificacion=" + idNotificacion +
                ", fechaEnvio=" + fechaEnvio +
                ", asunto='" + asunto + '\'' +
                ", mensaje='" + mensaje + '\'' +
                ", leida=" + leida +
                ", idPostulacion=" + idPostulacion +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idNotificacion;
        private LocalDateTime fechaEnvio;
        private String asunto;
        private String mensaje;
        private Boolean leida;
        private Integer idPostulacion;

        public Builder idNotificacion(Integer idNotificacion) { this.idNotificacion = idNotificacion; return this; }
        public Builder fechaEnvio(LocalDateTime fechaEnvio) { this.fechaEnvio = fechaEnvio; return this; }
        public Builder asunto(String asunto) { this.asunto = asunto; return this; }
        public Builder mensaje(String mensaje) { this.mensaje = mensaje; return this; }
        public Builder leida(Boolean leida) { this.leida = leida; return this; }
        public Builder idPostulacion(Integer idPostulacion) { this.idPostulacion = idPostulacion; return this; }

        public NotificacionDTO build() {
            return new NotificacionDTO(idNotificacion, fechaEnvio, asunto, mensaje, leida, idPostulacion);
        }
    }
}