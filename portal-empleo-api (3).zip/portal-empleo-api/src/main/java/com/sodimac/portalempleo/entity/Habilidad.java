package com.sodimac.portalempleo.entity;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import jakarta.persistence.*;

@Entity
@Table(name = "Habilidades")
public class Habilidad {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_habilidad")
    private Integer idHabilidad;

    @Column(name = "nombre_habilidad", nullable = false, unique = true, length = 100)
    private String nombreHabilidad;

    @OneToMany(mappedBy = "habilidad")
    private Set<HabilidadUsuario> usuariosConHabilidad = new HashSet<>();

    @OneToMany(mappedBy = "habilidad")
    private Set<HabilidadRequeridaPuesto> puestosQueRequieren = new HashSet<>();

    public Habilidad() {}

    public Habilidad(Integer idHabilidad, String nombreHabilidad,
                     Set<HabilidadUsuario> usuariosConHabilidad,
                     Set<HabilidadRequeridaPuesto> puestosQueRequieren) {
        this.idHabilidad = idHabilidad;
        this.nombreHabilidad = nombreHabilidad;
        this.usuariosConHabilidad = usuariosConHabilidad != null ? usuariosConHabilidad : new HashSet<>();
        this.puestosQueRequieren = puestosQueRequieren != null ? puestosQueRequieren : new HashSet<>();
    }

    public Integer getIdHabilidad() { return idHabilidad; }
    public void setIdHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; }

    public String getNombreHabilidad() { return nombreHabilidad; }
    public void setNombreHabilidad(String nombreHabilidad) { this.nombreHabilidad = nombreHabilidad; }

    public Set<HabilidadUsuario> getUsuariosConHabilidad() { return usuariosConHabilidad; }
    public void setUsuariosConHabilidad(Set<HabilidadUsuario> usuariosConHabilidad) {
        this.usuariosConHabilidad = usuariosConHabilidad != null ? usuariosConHabilidad : new HashSet<>();
    }

    public Set<HabilidadRequeridaPuesto> getPuestosQueRequieren() { return puestosQueRequieren; }
    public void setPuestosQueRequieren(Set<HabilidadRequeridaPuesto> puestosQueRequieren) {
        this.puestosQueRequieren = puestosQueRequieren != null ? puestosQueRequieren : new HashSet<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Habilidad)) return false;
        Habilidad that = (Habilidad) o;
        return Objects.equals(idHabilidad, that.idHabilidad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idHabilidad);
    }

    @Override
    public String toString() {
        return "Habilidad{" +
                "idHabilidad=" + idHabilidad +
                ", nombreHabilidad='" + nombreHabilidad + '\'' +
                '}';
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Integer idHabilidad;
        private String nombreHabilidad;
        private Set<HabilidadUsuario> usuariosConHabilidad;
        private Set<HabilidadRequeridaPuesto> puestosQueRequieren;

        public Builder idHabilidad(Integer idHabilidad) { this.idHabilidad = idHabilidad; return this; }
        public Builder nombreHabilidad(String nombreHabilidad) { this.nombreHabilidad = nombreHabilidad; return this; }
        public Builder usuariosConHabilidad(Set<HabilidadUsuario> usuariosConHabilidad) { this.usuariosConHabilidad = usuariosConHabilidad; return this; }
        public Builder puestosQueRequieren(Set<HabilidadRequeridaPuesto> puestosQueRequieren) { this.puestosQueRequieren = puestosQueRequieren; return this; }

        public Habilidad build() {
            return new Habilidad(idHabilidad, nombreHabilidad, usuariosConHabilidad, puestosQueRequieren);
        }
    }
}
