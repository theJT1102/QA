package com.sodimac.portalempleo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalEmpleoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
